<#
.SYNOPSIS
    Script maître - Collecte toutes les informations VDI et génère le fichier Excel de référence.
.DESCRIPTION
    Orchestre les 4 modules de collecte (AD, MECM, Horizon, vSphere, Réseau)
    et produit un classeur Excel complet avec mise en forme professionnelle.
.PARAMETER HorizonServer
    FQDN du Connection Server Horizon (ex: hzn-cs01.domain.local)
.PARAMETER vCenterServer
    FQDN du vCenter (ex: vcenter.domain.local)
.PARAMETER SiteCodeMECM
    Code site MECM (ex: P01)
.PARAMETER OutputPath
    Dossier de sortie (défaut: .\output)
.PARAMETER SkipModules
    Modules à ignorer : "AD","MECM","Horizon","vSphere","Network"
.EXAMPLE
    .\00_Invoke-VDI-Inventory.ps1 -HorizonServer "hzn-cs01.corp.local" -vCenterServer "vc01.corp.local"
#>

[CmdletBinding()]
param(
    [string]$HorizonServer,
    [string]$vCenterServer,
    [string]$SiteCodeMECM,
    [string]$OutputPath  = "$PSScriptRoot\..\output",
    [string[]]$SkipModules = @(),
    [switch]$NoExcel     # Exporte uniquement en JSON
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Continue"
$StartTime = Get-Date

function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $color = switch ($Level) { "ERROR" { "Red" } "WARN" { "Yellow" } "OK" { "Green" } "TITLE" { "Magenta" } default { "Cyan" } }
    Write-Host "[$ts] [$Level] $Message" -ForegroundColor $color
}

function Request-Credential {
    param([string]$Prompt)
    return (Get-Credential -Message $Prompt)
}

if (-not (Test-Path $OutputPath)) { New-Item -ItemType Directory -Path $OutputPath -Force | Out-Null }

Write-Log "╔══════════════════════════════════════════════════════╗" "TITLE"
Write-Log "║       VDI OPS KIT - COLLECTE INFRASTRUCTURE         ║" "TITLE"
Write-Log "╚══════════════════════════════════════════════════════╝" "TITLE"
Write-Log "Début : $StartTime | Sortie : $OutputPath"

$AllData = [ordered]@{}

# ═══════════════════════════════════════════
# MODULE 1 : ACTIVE DIRECTORY
# ═══════════════════════════════════════════
if ("AD" -notin $SkipModules) {
    Write-Log "── MODULE 1/5 : Active Directory ──" "TITLE"
    try {
        $ADData = & "$PSScriptRoot\01_Collect-ADInfo.ps1"
        $AllData["AD"] = $ADData
        Write-Log "Module AD OK" "OK"
    } catch {
        Write-Log "Module AD ÉCHEC : $_" "ERROR"
        $AllData["AD"] = @{ Erreur = $_.Exception.Message }
    }
}

# ═══════════════════════════════════════════
# MODULE 2 : MECM/SCCM
# ═══════════════════════════════════════════
if ("MECM" -notin $SkipModules) {
    Write-Log "── MODULE 2/5 : MECM/SCCM ──" "TITLE"
    try {
        $mecmParams = @{}
        if ($SiteCodeMECM) { $mecmParams["SiteCode"] = $SiteCodeMECM }
        $MECMData = & "$PSScriptRoot\02_Collect-MECMInfo.ps1" @mecmParams
        $AllData["MECM"] = $MECMData
        Write-Log "Module MECM OK" "OK"
    } catch {
        Write-Log "Module MECM ÉCHEC : $_" "ERROR"
        $AllData["MECM"] = @{ Erreur = $_.Exception.Message }
    }
}

# ═══════════════════════════════════════════
# MODULE 3 : VMWARE HORIZON
# ═══════════════════════════════════════════
if ("Horizon" -notin $SkipModules -and $HorizonServer) {
    Write-Log "── MODULE 3/5 : VMware Horizon ──" "TITLE"
    $hznCred = Request-Credential "Identifiants Horizon (domaine\utilisateur)"
    try {
        $HorizonData = & "$PSScriptRoot\03_Collect-HorizonInfo.ps1" `
            -HorizonServer $HorizonServer `
            -HorizonCredential $hznCred
        $AllData["Horizon"] = $HorizonData
        Write-Log "Module Horizon OK" "OK"
    } catch {
        Write-Log "Module Horizon ÉCHEC : $_" "ERROR"
        $AllData["Horizon"] = @{ Erreur = $_.Exception.Message }
    }
} elseif ("Horizon" -notin $SkipModules) {
    Write-Log "HorizonServer non spécifié - module ignoré" "WARN"
}

# ═══════════════════════════════════════════
# MODULE 4 : VSPHERE
# ═══════════════════════════════════════════
if ("vSphere" -notin $SkipModules -and $vCenterServer) {
    Write-Log "── MODULE 4/5 : vSphere/vCenter ──" "TITLE"
    $vcCred = Request-Credential "Identifiants vCenter"
    try {
        $vSphereData = & "$PSScriptRoot\04_Collect-vSphereInfo.ps1" `
            -vCenterServer $vCenterServer `
            -vCenterCredential $vcCred
        $AllData["vSphere"] = $vSphereData
        Write-Log "Module vSphere OK" "OK"
    } catch {
        Write-Log "Module vSphere ÉCHEC : $_" "ERROR"
        $AllData["vSphere"] = @{ Erreur = $_.Exception.Message }
    }
} elseif ("vSphere" -notin $SkipModules) {
    Write-Log "vCenterServer non spécifié - module ignoré" "WARN"
}

# ═══════════════════════════════════════════
# MODULE 5 : RÉSEAU / DNS / DHCP
# ═══════════════════════════════════════════
if ("Network" -notin $SkipModules) {
    Write-Log "── MODULE 5/5 : Réseau / DNS / DHCP ──" "TITLE"
    try {
        $NetworkData = & "$PSScriptRoot\05_Collect-NetworkInfo.ps1"
        $AllData["Network"] = $NetworkData
        Write-Log "Module Réseau OK" "OK"
    } catch {
        Write-Log "Module Réseau ÉCHEC : $_" "ERROR"
        $AllData["Network"] = @{ Erreur = $_.Exception.Message }
    }
}

# ═══════════════════════════════════════════
# EXPORT JSON GLOBAL
# ═══════════════════════════════════════════
$jsonFile = "$OutputPath\VDI_Inventory_$(Get-Date -Format 'yyyyMMdd_HHmm').json"
$AllData | ConvertTo-Json -Depth 15 | Out-File $jsonFile -Encoding UTF8
Write-Log "Export JSON global : $jsonFile" "OK"

# ═══════════════════════════════════════════
# GÉNÉRATION EXCEL
# ═══════════════════════════════════════════
if (-not $NoExcel) {
    Write-Log "── GÉNÉRATION DU FICHIER EXCEL ──" "TITLE"
    $xlsxFile = "$OutputPath\VDI_OpsKit_$(Get-Date -Format 'yyyyMMdd_HHmm').xlsx"
    $pythonScript = "$PSScriptRoot\06_Generate-Excel.py"

    if (Test-Path $pythonScript) {
        try {
            $result = python $pythonScript --json $jsonFile --output $xlsxFile 2>&1
            Write-Log "Excel généré : $xlsxFile" "OK"
        } catch {
            Write-Log "Erreur génération Excel : $_" "ERROR"
        }
    } else {
        Write-Log "Script Python non trouvé : $pythonScript" "WARN"
        Write-Log "Lancez manuellement : python 06_Generate-Excel.py --json $jsonFile --output $xlsxFile" "WARN"
    }
}

$duration = (Get-Date) - $StartTime
Write-Log "═══ COLLECTE TERMINÉE en $([math]::Round($duration.TotalMinutes,1)) min ═══" "OK"
Write-Log "JSON    : $jsonFile"
if (-not $NoExcel) { Write-Log "Excel   : $xlsxFile" }
