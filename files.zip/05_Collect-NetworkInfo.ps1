<#
.SYNOPSIS
    Collecte toutes les informations réseau, DNS, DHCP nécessaires à la gestion VDI.
.DESCRIPTION
    Récupère : DNS (zones, records VDI), DHCP (scopes, options, réservations VDI),
               NTP, Proxy, Certificats, Pare-feu Windows
#>

[CmdletBinding()]
param(
    [string[]]$DNSServers,           # Si vide : auto-détecte depuis AD
    [string[]]$DHCPServers,          # Si vide : auto-détecte depuis AD
    [string]$OutputPath = "$PSScriptRoot\..\output",
    [switch]$ExportJson
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Continue"

function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $color = switch ($Level) { "ERROR" { "Red" } "WARN" { "Yellow" } "OK" { "Green" } default { "Cyan" } }
    Write-Host "[$ts] [$Level] $Message" -ForegroundColor $color
}

Write-Log "=== COLLECTE RÉSEAU / DNS / DHCP ===" "OK"

# Auto-découverte DNS & DHCP depuis AD
if (-not $DNSServers) {
    try {
        $DNSServers = (Get-ADDomainController -Filter *).IPv4Address
        Write-Log "DNS auto-détectés : $($DNSServers -join ', ')" "OK"
    } catch { $DNSServers = @("127.0.0.1") }
}
if (-not $DHCPServers) {
    try {
        $DHCPServers = (Get-DhcpServerInDC).IPAddress.IPAddressToString
        Write-Log "DHCP auto-détectés : $($DHCPServers -join ', ')" "OK"
    } catch { $DHCPServers = @() }
}

$NetworkData = [ordered]@{}

# ─────────────────────────────────────────
# 1. INFO RÉSEAU LOCALE (hôte courant)
# ─────────────────────────────────────────
Write-Log "Collecte infos réseau locales..."
try {
    $NICs = Get-NetAdapter | Where-Object { $_.Status -eq "Up" } | ForEach-Object {
        $nic = $_
        $ip  = Get-NetIPAddress -InterfaceIndex $nic.InterfaceIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue
        $gw  = (Get-NetRoute -InterfaceIndex $nic.InterfaceIndex -DestinationPrefix "0.0.0.0/0" -ErrorAction SilentlyContinue).NextHop
        $dns = (Get-DnsClientServerAddress -InterfaceIndex $nic.InterfaceIndex -AddressFamily IPv4).ServerAddresses
        [ordered]@{
            Interface  = $nic.Name
            Description= $nic.InterfaceDescription
            MAC        = $nic.MacAddress
            Vitesse    = "$([math]::Round($nic.LinkSpeed / 1Gbps, 0)) Gbps"
            IP         = $ip.IPAddress
            Masque     = $ip.PrefixLength
            Passerelle = $gw
            DNS        = $dns -join " | "
            MTU        = $nic.MtuSize
            VLAN       = (Get-NetAdapterAdvancedProperty -Name $nic.Name -DisplayName "VLAN ID" -ErrorAction SilentlyContinue).DisplayValue
        }
    }
    $NetworkData["NICsLocaux"] = $NICs
    Write-Log "$($NICs.Count) interface(s) réseau active(s)" "OK"
} catch { Write-Log "Erreur NICs : $_" "ERROR" }

# ─────────────────────────────────────────
# 2. ZONES DNS
# ─────────────────────────────────────────
Write-Log "Collecte des zones DNS..."
foreach ($dnsServer in $DNSServers) {
    try {
        $zones = Get-DnsServerZone -ComputerName $dnsServer -ErrorAction Stop |
            Select-Object ZoneName, ZoneType, IsDsIntegrated, IsReverseLookupZone,
                DynamicUpdate, IsAutoCreated,
                @{N="Serveur";E={ $dnsServer }},
                @{N="NbRecords";E={
                    try { (Get-DnsServerResourceRecord -ComputerName $dnsServer -ZoneName $_.ZoneName -ErrorAction SilentlyContinue).Count }
                    catch { "N/A" }
                }}
        $NetworkData["ZonesDNS_$($dnsServer -replace '[.\-]','_')"] = $zones
        Write-Log "$($zones.Count) zone(s) DNS sur $dnsServer" "OK"
    } catch {
        Write-Log "Erreur zones DNS $dnsServer : $_" "WARN"
    }
}

# ─────────────────────────────────────────
# 3. RECORDS DNS VDI
# ─────────────────────────────────────────
Write-Log "Collecte des records DNS liés VDI..."
foreach ($dnsServer in $DNSServers) {
    try {
        $zones = Get-DnsServerZone -ComputerName $dnsServer -ZoneType Primary -ErrorAction Stop
        $vdiRecords = foreach ($zone in $zones) {
            Get-DnsServerResourceRecord -ComputerName $dnsServer -ZoneName $zone.ZoneName -ErrorAction SilentlyContinue |
                Where-Object { $_.HostName -match "vdi|hzn|horizon|view|rds|vda|pool|thin" } |
                Select-Object @(
                    @{N="Zone";E={ $zone.ZoneName }},
                    "HostName", "RecordType",
                    @{N="Donnee";E={ $_.RecordData.IPv4Address ?? $_.RecordData.HostNameAlias ?? $_.RecordData.NameServer ?? "N/A" }},
                    @{N="TTL";E={ $_.TimeToLive.TotalSeconds }},
                    @{N="Serveur";E={ $dnsServer }}
                )
        }
        $NetworkData["RecordsDNS_VDI"] = $vdiRecords
        Write-Log "$(@($vdiRecords).Count) record(s) DNS VDI trouvé(s)" "OK"
    } catch { Write-Log "Erreur records DNS VDI : $_" "WARN" }
    break  # On collecte depuis 1 seul DNS pour éviter les doublons
}

# ─────────────────────────────────────────
# 4. SCOPES DHCP
# ─────────────────────────────────────────
Write-Log "Collecte des scopes DHCP..."
foreach ($dhcpServer in $DHCPServers) {
    try {
        $scopes = Get-DhcpServerv4Scope -ComputerName $dhcpServer -ErrorAction Stop |
            Select-Object @(
                @{N="Serveur";E={ $dhcpServer }},
                "ScopeId", "Name", "SubnetMask", "StartRange", "EndRange",
                @{N="Passerelle";E={ (Get-DhcpServerv4OptionValue -ComputerName $dhcpServer -ScopeId $_.ScopeId -OptionId 3 -ErrorAction SilentlyContinue).Value -join " | " }},
                @{N="DNS";E={ (Get-DhcpServerv4OptionValue -ComputerName $dhcpServer -ScopeId $_.ScopeId -OptionId 6 -ErrorAction SilentlyContinue).Value -join " | " }},
                "State",
                @{N="LeaseDuration";E={ $_.LeaseDuration.TotalHours.ToString() + "h" }},
                @{N="NbBaux";E={ (Get-DhcpServerv4Lease -ComputerName $dhcpServer -ScopeId $_.ScopeId -ErrorAction SilentlyContinue).Count }},
                @{N="NbResa";E={ (Get-DhcpServerv4Reservation -ComputerName $dhcpServer -ScopeId $_.ScopeId -ErrorAction SilentlyContinue).Count }}
            )
        $NetworkData["ScopesDHCP_$($dhcpServer -replace '[.\-]','_')"] = $scopes
        Write-Log "$($scopes.Count) scope(s) DHCP sur $dhcpServer" "OK"
    } catch { Write-Log "Erreur scopes DHCP $dhcpServer : $_" "WARN" }
}

# ─────────────────────────────────────────
# 5. CERTIFICATS (sur la machine courante & Horizon Connection Servers si accessibles)
# ─────────────────────────────────────────
Write-Log "Collecte des certificats..."
try {
    $Certs = Get-ChildItem -Path "Cert:\LocalMachine\My" |
        Where-Object { $_.NotAfter -gt (Get-Date) } |
        Select-Object @(
            @{N="Sujet";E={ $_.Subject }},
            @{N="Emetteur";E={ $_.Issuer }},
            @{N="SerialNumber";E={ $_.SerialNumber }},
            @{N="Expire";E={ $_.NotAfter.ToString("yyyy-MM-dd") }},
            @{N="JoursRestants";E={ ([int]($_.NotAfter - (Get-Date)).TotalDays) }},
            @{N="Thumbprint";E={ $_.Thumbprint }},
            @{N="Alerte";E={ if (($_.NotAfter - (Get-Date)).TotalDays -lt 60) { "ATTENTION < 60j" } else { "OK" } }},
            @{N="SAN";E={ ($_.Extensions | Where-Object { $_.Oid.FriendlyName -eq "Subject Alternative Name" }).Format($false) }}
        ) | Sort-Object JoursRestants
    $NetworkData["Certificats"] = $Certs
    Write-Log "$($Certs.Count) certificat(s) valide(s) trouvé(s)" "OK"
} catch { Write-Log "Erreur certificats : $_" "ERROR" }

# ─────────────────────────────────────────
# 6. CONFIGURATION NTP
# ─────────────────────────────────────────
Write-Log "Collecte de la configuration NTP..."
try {
    $ntpConfig = w32tm /query /configuration 2>&1
    $ntpPeers  = w32tm /query /peers 2>&1
    $ntpStatus = w32tm /query /status 2>&1
    $NetworkData["NTP"] = [ordered]@{
        Configuration = ($ntpConfig | Where-Object { $_ -match "NtpServer|Type|Enabled" }) -join "`n"
        Peers         = $ntpPeers -join "`n"
        Status        = $ntpStatus -join "`n"
    }
    Write-Log "Configuration NTP collectée" "OK"
} catch { Write-Log "Erreur NTP : $_" "ERROR" }

# ─────────────────────────────────────────
# 7. PROXY RÉSEAU
# ─────────────────────────────────────────
Write-Log "Collecte de la configuration proxy..."
try {
    $proxyReg = Get-ItemProperty -Path "HKLM:\Software\Policies\Microsoft\Windows\CurrentVersion\Internet Settings" -ErrorAction SilentlyContinue
    $proxyUser = Get-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings" -ErrorAction SilentlyContinue
    $NetworkData["Proxy"] = [ordered]@{
        ProxyGPO        = $proxyReg.ProxyServer
        ProxyActiveUser = $proxyUser.ProxyServer
        ProxyEnable     = $proxyUser.ProxyEnable
        BypassList      = $proxyUser.ProxyOverride
        AutoConfig      = $proxyUser.AutoConfigURL
    }
    Write-Log "Configuration proxy collectée" "OK"
} catch { Write-Log "Erreur Proxy : $_" "ERROR" }

# ─────────────────────────────────────────
# 8. FIREWALL WINDOWS (profils & règles VDI)
# ─────────────────────────────────────────
Write-Log "Collecte des règles pare-feu..."
try {
    $FWProfiles = Get-NetFirewallProfile | Select-Object Name, Enabled, DefaultInboundAction, DefaultOutboundAction
    $FWRules = Get-NetFirewallRule | Where-Object {
        $_.DisplayName -match "Horizon|VMware|VDI|RDS|PCoIP|Blast|CBM|MECM|SCCM|WinRM"
        -and $_.Enabled -eq "True"
    } | Select-Object DisplayName, Direction, Action, Protocol,
        @{N="LocalPort";E={ ($_ | Get-NetFirewallPortFilter).LocalPort }},
        @{N="RemotePort";E={ ($_ | Get-NetFirewallPortFilter).RemotePort }},
        Profile, Description
    $NetworkData["FirewallProfils"] = $FWProfiles
    $NetworkData["FirewallReglesVDI"] = $FWRules
    Write-Log "$($FWRules.Count) règle(s) pare-feu VDI active(s)" "OK"
} catch { Write-Log "Erreur Firewall : $_" "ERROR" }

if ($ExportJson) {
    if (-not (Test-Path $OutputPath)) { New-Item -ItemType Directory -Path $OutputPath | Out-Null }
    $NetworkData | ConvertTo-Json -Depth 10 | Out-File "$OutputPath\Network_Info.json" -Encoding UTF8
    Write-Log "Export JSON : $OutputPath\Network_Info.json" "OK"
}

Write-Log "=== COLLECTE RÉSEAU TERMINÉE ===" "OK"
return $NetworkData
