#!/usr/bin/env python3
"""
VDI OpsKit - Générateur Excel
Construit un classeur Excel structuré et formaté à partir du JSON de collecte.
Usage: python 06_Generate-Excel.py --json inventory.json --output VDI_OpsKit.xlsx
"""

import argparse
import json
import sys
import os
from datetime import datetime
from openpyxl import Workbook
from openpyxl.styles import (
    Font, PatternFill, Alignment, Border, Side, GradientFill
)
from openpyxl.styles.numbers import FORMAT_DATE_DATETIME
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.table import Table, TableStyleInfo
from openpyxl.chart import BarChart, Reference
from openpyxl.drawing.image import Image
from openpyxl.worksheet.datavalidation import DataValidation

# ─────────────────────────────────────────
# PALETTE COULEURS
# ─────────────────────────────────────────
CLR = {
    "bg_title":    "1F3864",  # Bleu marine foncé
    "bg_header":   "2E75B6",  # Bleu
    "bg_header2":  "4472C4",  # Bleu moyen
    "bg_section":  "D6E4F7",  # Bleu très clair
    "bg_alt":      "EBF3FB",  # Alternance lignes
    "bg_warn":     "FFF2CC",  # Jaune alerte
    "bg_error":    "FCE4D6",  # Rouge alerte
    "bg_ok":       "E2EFDA",  # Vert OK
    "txt_white":   "FFFFFF",
    "txt_dark":    "1F1F1F",
    "txt_blue":    "1F3864",
    "accent":      "ED7D31",  # Orange accent
    "border":      "BDD7EE",
}

FONT_TITLE  = Font(name="Arial", size=14, bold=True, color=CLR["txt_white"])
FONT_HEADER = Font(name="Arial", size=9,  bold=True, color=CLR["txt_white"])
FONT_BODY   = Font(name="Arial", size=9)
FONT_BOLD   = Font(name="Arial", size=9, bold=True)
FONT_SMALL  = Font(name="Arial", size=8, color="595959")

ALIGN_CENTER = Alignment(horizontal="center", vertical="center", wrap_text=False)
ALIGN_LEFT   = Alignment(horizontal="left",   vertical="center", wrap_text=False)
ALIGN_WRAP   = Alignment(horizontal="left",   vertical="top",    wrap_text=True)

THIN_BORDER = Border(
    left=Side(style="thin", color=CLR["border"]),
    right=Side(style="thin", color=CLR["border"]),
    top=Side(style="thin", color=CLR["border"]),
    bottom=Side(style="thin", color=CLR["border"])
)

def fill(hex_color):
    return PatternFill("solid", fgColor=hex_color)

def set_col_widths(ws, widths: dict):
    for col_letter, width in widths.items():
        ws.column_dimensions[col_letter].width = width

def freeze(ws, cell="B2"):
    ws.freeze_panes = cell

def add_title_row(ws, title, subtitle="", merge_cols=10):
    ws.row_dimensions[1].height = 32
    ws.row_dimensions[2].height = 18
    ws.merge_cells(f"A1:{get_column_letter(merge_cols)}1")
    c = ws["A1"]
    c.value = f"  {title}"
    c.font = Font(name="Arial", size=14, bold=True, color=CLR["txt_white"])
    c.fill = fill(CLR["bg_title"])
    c.alignment = Alignment(horizontal="left", vertical="center")
    if subtitle:
        ws.merge_cells(f"A2:{get_column_letter(merge_cols)}2")
        c2 = ws["A2"]
        c2.value = f"  {subtitle}  —  Généré le {datetime.now().strftime('%d/%m/%Y à %H:%M')}"
        c2.font = FONT_SMALL
        c2.fill = fill("344B6E")
        c2.font = Font(name="Arial", size=8, color="C9D9F0", italic=True)
        c2.alignment = Alignment(horizontal="left", vertical="center")
    return 3  # prochaine ligne dispo

def add_section_header(ws, row, label, nb_cols=10):
    ws.row_dimensions[row].height = 16
    ws.merge_cells(f"A{row}:{get_column_letter(nb_cols)}{row}")
    c = ws.cell(row=row, column=1, value=f"  ▸  {label}")
    c.font = Font(name="Arial", size=9, bold=True, color=CLR["txt_blue"])
    c.fill = fill(CLR["bg_section"])
    c.alignment = ALIGN_LEFT
    for col in range(1, nb_cols+1):
        ws.cell(row=row, column=col).border = THIN_BORDER
    return row + 1

def add_table_headers(ws, row, headers: list):
    ws.row_dimensions[row].height = 20
    for col, header in enumerate(headers, 1):
        c = ws.cell(row=row, column=col, value=header)
        c.font = FONT_HEADER
        c.fill = fill(CLR["bg_header"])
        c.alignment = ALIGN_CENTER
        c.border = THIN_BORDER
    return row + 1

def add_data_row(ws, row, values: list, highlight=None):
    bg = CLR["bg_alt"] if row % 2 == 0 else "FFFFFF"
    if highlight == "WARN": bg = CLR["bg_warn"]
    elif highlight == "ERROR": bg = CLR["bg_error"]
    elif highlight == "OK": bg = CLR["bg_ok"]
    ws.row_dimensions[row].height = 16
    for col, val in enumerate(values, 1):
        if val is None: val = ""
        c = ws.cell(row=row, column=col, value=str(val) if not isinstance(val, (int, float)) else val)
        c.font = FONT_BODY
        c.fill = fill(bg)
        c.alignment = ALIGN_LEFT
        c.border = THIN_BORDER
    return row + 1

def add_kv_section(ws, start_row, data: dict, label="", nb_cols=6):
    if label:
        start_row = add_section_header(ws, start_row, label, nb_cols)
    for key, val in data.items():
        if val is None: val = "N/A"
        ws.row_dimensions[start_row].height = 16
        kc = ws.cell(row=start_row, column=1, value=key)
        kc.font = FONT_BOLD
        kc.fill = fill("EEF4FA")
        kc.alignment = ALIGN_LEFT
        kc.border = THIN_BORDER
        ws.merge_cells(f"B{start_row}:{get_column_letter(nb_cols)}{start_row}")
        vc = ws.cell(row=start_row, column=2, value=str(val))
        vc.font = FONT_BODY
        vc.fill = fill("FFFFFF")
        vc.alignment = ALIGN_WRAP
        vc.border = THIN_BORDER
        start_row += 1
    return start_row + 1

def safe_list(data, key, default=None):
    if isinstance(data, dict):
        v = data.get(key, default)
        if v is None: return []
        if isinstance(v, list): return v
        if isinstance(v, dict): return [v]
    return []

# ═════════════════════════════════════════════════════
# FEUILLE : SOMMAIRE
# ═════════════════════════════════════════════════════
def build_sheet_summary(wb, data):
    ws = wb.create_sheet("📋 Sommaire", 0)
    ws.sheet_view.showGridLines = False
    ws.column_dimensions["A"].width = 3
    ws.column_dimensions["B"].width = 28
    ws.column_dimensions["C"].width = 40
    ws.column_dimensions["D"].width = 18
    ws.column_dimensions["E"].width = 18

    row = add_title_row(ws, "VDI OPS KIT — TABLEAU DE BORD", "Vue d'ensemble de l'infrastructure VDI", 5)

    # Bloc méta
    row = add_section_header(ws, row, "Informations de collecte", 5)
    meta = {
        "Date de collecte" : datetime.now().strftime("%d/%m/%Y %H:%M"),
        "Collecté par"     : os.environ.get("USERNAME", "N/A"),
        "Machine"          : os.environ.get("COMPUTERNAME", "N/A"),
        "Domaine"          : data.get("AD", {}).get("Domaine", {}).get("NomDNS", "N/A"),
        "Site MECM"        : data.get("MECM", {}).get("Site", {}).get("SiteCode", "N/A"),
        "Version Horizon"  : data.get("Horizon", {}).get("Environnement", {}).get("Version", "N/A"),
        "vCenter"          : data.get("vSphere", {}).get("vCenter", {}).get("Serveur", "N/A"),
    }
    row = add_kv_section(ws, row, meta, nb_cols=5)

    # Compteurs rapides
    row = add_section_header(ws, row, "Compteurs clés", 5)
    row = add_table_headers(ws, row, ["Domaine", "Valeur", "Statut", "Onglet de référence", "Note"])

    counters = [
        ("Contrôleurs de domaine", len(safe_list(data.get("AD",{}), "ControleursDeDomaine")), "OK", "🏢 AD - Domaine"),
        ("GPOs actives",           len(safe_list(data.get("AD",{}), "GPOs")), "INFO", "🏢 AD - GPOs"),
        ("Comptes de service",     len(safe_list(data.get("AD",{}), "ComptesService")), "INFO", "🏢 AD - Comptes"),
        ("Desktop Pools Horizon",  len(safe_list(data.get("Horizon",{}), "DesktopPools")), "OK", "🖥 Horizon - Pools"),
        ("Machines VDI totales",   len(safe_list(data.get("Horizon",{}), "Machines")), "OK", "🖥 Horizon - Machines"),
        ("Sessions actives",       len(safe_list(data.get("Horizon",{}), "Sessions")), "INFO", "🖥 Horizon - Sessions"),
        ("Hosts ESXi",             len(safe_list(data.get("vSphere",{}), "HostsESXi")), "OK", "⚡ vSphere - Hosts"),
        ("Datastores",             len(safe_list(data.get("vSphere",{}), "Datastores")), "OK", "⚡ vSphere - Storage"),
        ("Clusters vSphere",       len(safe_list(data.get("vSphere",{}), "Clusters")), "OK", "⚡ vSphere - Clusters"),
        ("Collections MECM VDI",   len(safe_list(data.get("MECM",{}), "CollectionsVDI")), "OK", "🔧 MECM - Collections"),
        ("Task Sequences",         len(safe_list(data.get("MECM",{}), "TaskSequences")), "INFO", "🔧 MECM - Séquences"),
        ("Certificats (expire <60j)", sum(1 for c in safe_list(data.get("Network",{}), "Certificats")
                                         if "ATTENTION" in str(c.get("Alerte",""))), "WARN", "🌐 Réseau - Certs"),
    ]

    for domaine, val, statut, onglet in counters:
        hl = "WARN" if statut == "WARN" else ("ERROR" if statut == "ERROR" else None)
        row = add_data_row(ws, row, [domaine, val, statut, onglet, ""], highlight=hl)

    freeze(ws, "B4")

# ═════════════════════════════════════════════════════
# FEUILLE : AD
# ═════════════════════════════════════════════════════
def build_sheet_ad(wb, ad_data):
    ws = wb.create_sheet("🏢 AD - Domaine")
    ws.sheet_view.showGridLines = False
    row = add_title_row(ws, "ACTIVE DIRECTORY — Informations de domaine", "Domaine, DCs, Sites, GPOs, Comptes", 10)

    # Domaine
    domaine = ad_data.get("Domaine", {})
    if domaine:
        row = add_kv_section(ws, row, domaine, "Informations Domaine & Forêt", 10)

    # DCs
    dcs = safe_list(ad_data, "ControleursDeDomaine")
    if dcs:
        row = add_section_header(ws, row, f"Contrôleurs de domaine ({len(dcs)})", 10)
        headers = ["Nom", "IP", "Site", "GC", "ReadOnly", "OS", "Version OS", "Rôles FSMO", "Activé", "Ping"]
        row = add_table_headers(ws, row, headers)
        for dc in dcs:
            hl = None if dc.get("Ping") == "True" else "WARN"
            row = add_data_row(ws, row, [
                dc.get("Name"), dc.get("IPv4Address"), dc.get("Site"),
                dc.get("IsGlobalCatalog"), dc.get("IsReadOnly"),
                dc.get("OperatingSystem"), dc.get("OperatingSystemVersion"),
                dc.get("FSMO"), dc.get("Enabled"), dc.get("Ping")
            ], highlight=hl)

    # Sites AD
    sites = safe_list(ad_data, "SitesAD")
    if sites:
        row += 1
        row = add_section_header(ws, row, f"Sites AD ({len(sites)})", 10)
        row = add_table_headers(ws, row, ["Nom du site", "Subnets associés", "Distinguished Name"])
        for s in sites:
            row = add_data_row(ws, row, [s.get("Name"), s.get("Subnets"), s.get("DistinguishedName")])

    set_col_widths(ws, {"A": 28, "B": 18, "C": 18, "D": 8, "E": 10, "F": 28, "G": 18, "H": 32, "I": 8, "J": 8})
    freeze(ws, "A4")

def build_sheet_gpo(wb, ad_data):
    ws = wb.create_sheet("🏢 AD - GPOs")
    ws.sheet_view.showGridLines = False
    row = add_title_row(ws, "ACTIVE DIRECTORY — Stratégies de groupe (GPO)", "", 8)

    gpos = safe_list(ad_data, "GPOs")
    if gpos:
        row = add_section_header(ws, row, f"GPOs ({len(gpos)})", 8)
        row = add_table_headers(ws, row, ["Nom", "GUID", "Statut", "Créée", "Modifiée", "Filtre WMI", "OUs liées"])
        for gpo in sorted(gpos, key=lambda x: x.get("DisplayName", "")):
            row = add_data_row(ws, row, [
                gpo.get("DisplayName"), gpo.get("Id"), gpo.get("GpoStatus"),
                gpo.get("CreationDate"), gpo.get("ModifiedDate"),
                gpo.get("WMIFilter"), gpo.get("LinkedOUs")
            ])

    # Comptes de service
    svc = safe_list(ad_data, "ComptesService")
    if svc:
        row += 1
        row = add_section_header(ws, row, f"Comptes de service ({len(svc)})", 8)
        row = add_table_headers(ws, row, ["SamAccountName", "Nom", "Description", "Activé", "Pwd Change", "Pwd No Expiry", "Dernière connexion", "Expiration"])
        for s in svc:
            exp_days = None
            try:
                if s.get("Expiration"):
                    exp_days = (datetime.strptime(s["Expiration"], "%Y-%m-%d") - datetime.now()).days
            except: pass
            hl = "WARN" if (exp_days is not None and exp_days < 30) else None
            row = add_data_row(ws, row, [
                s.get("SamAccountName"), s.get("DisplayName"), s.get("Description"),
                s.get("Enabled"), s.get("PasswordLastSet"), s.get("PasswordNeverExpires"),
                s.get("LastLogon"), s.get("Expiration")
            ], highlight=hl)

    set_col_widths(ws, {"A": 32, "B": 32, "C": 12, "D": 14, "E": 14, "F": 28, "G": 42})
    freeze(ws, "A4")

# ═════════════════════════════════════════════════════
# FEUILLE : MECM
# ═════════════════════════════════════════════════════
def build_sheet_mecm(wb, mecm_data):
    ws = wb.create_sheet("🔧 MECM")
    ws.sheet_view.showGridLines = False
    row = add_title_row(ws, "MECM/SCCM — Configuration & Collections VDI", "", 9)

    site = mecm_data.get("Site", {})
    if site:
        row = add_kv_section(ws, row, site, "Informations Site MECM", 9)

    roles = safe_list(mecm_data, "RolesSite")
    if roles:
        row = add_section_header(ws, row, f"Serveurs de site & Rôles ({len(roles)})", 9)
        row = add_table_headers(ws, row, ["Serveur", "Rôles", "Site Code", "Dernière activité"])
        for r in roles:
            row = add_data_row(ws, row, [r.get("Serveur"), r.get("Roles"), r.get("SiteCode"), r.get("LastOnline")])

    colls = safe_list(mecm_data, "CollectionsVDI")
    if colls:
        row += 1
        row = add_section_header(ws, row, f"Collections VDI ({len(colls)})", 9)
        row = add_table_headers(ws, row, ["Nom", "ID", "Commentaire", "Nb membres", "Limité à", "Actualisation", "Dernier refresh", "Règle WQL"])
        for c in sorted(colls, key=lambda x: x.get("Name", "")):
            row = add_data_row(ws, row, [
                c.get("Name"), c.get("CollectionID"), c.get("Comment"),
                c.get("MemberCount"), c.get("LimitToCollectionName"),
                c.get("RefreshType"), c.get("LastRefresh"), c.get("QueryRule")
            ])

    ts = safe_list(mecm_data, "TaskSequences")
    if ts:
        row += 1
        row = add_section_header(ws, row, f"Séquences de tâches ({len(ts)})", 9)
        row = add_table_headers(ws, row, ["Nom", "ID", "Modifiée", "Boot Image", "Nb déploiements", "Package ID"])
        for t in ts:
            row = add_data_row(ws, row, [
                t.get("Name"), t.get("SequenceID"), t.get("Modifie"),
                t.get("BootImage"), t.get("Deploiements"), t.get("PackageID")
            ])

    mw = safe_list(mecm_data, "MaintenanceWindows")
    if mw:
        row += 1
        row = add_section_header(ws, row, f"Fenêtres de maintenance ({len(mw)})", 9)
        row = add_table_headers(ws, row, ["Collection", "Nom", "Activée", "Durée (h)", "Récurrence", "Type"])
        for m in mw:
            row = add_data_row(ws, row, [
                m.get("Collection"), m.get("Name"), m.get("IsEnabled"),
                m.get("DurationHours"), m.get("Recurrence"), m.get("Type")
            ])

    set_col_widths(ws, {"A": 34, "B": 14, "C": 22, "D": 10, "E": 22, "F": 16, "G": 18, "H": 50, "I": 14})
    freeze(ws, "A4")

# ═════════════════════════════════════════════════════
# FEUILLE : HORIZON
# ═════════════════════════════════════════════════════
def build_sheet_horizon(wb, hzn_data):
    ws = wb.create_sheet("🖥 Horizon - Pools")
    ws.sheet_view.showGridLines = False
    row = add_title_row(ws, "VMWARE HORIZON — Connection Servers & Desktop Pools", "", 12)

    env = hzn_data.get("Environnement", {})
    if env:
        row = add_kv_section(ws, row, env, "Informations Environnement Horizon", 12)

    cs = safe_list(hzn_data, "ConnectionServers")
    if cs:
        row = add_section_header(ws, row, f"Connection Servers ({len(cs)})", 12)
        row = add_table_headers(ws, row, ["Nom", "Version", "Statut", "Sessions", "IP/FQDN", "Rôle", "Cert Expiry"])
        for s in cs:
            hl = None if s.get("Statut") == "OK" else "WARN"
            row = add_data_row(ws, row, [
                s.get("Nom"), s.get("Version"), s.get("Statut"),
                s.get("SessionsActives"), s.get("IP"), s.get("Role"), s.get("CertExpiry")
            ], highlight=hl)

    pools = safe_list(hzn_data, "DesktopPools")
    if pools:
        row += 1
        row = add_section_header(ws, row, f"Desktop Pools ({len(pools)})", 12)
        row = add_table_headers(ws, row, [
            "Nom", "Affichage", "Type", "Source (Clone)", "Protocole",
            "Activé", "Nb Machines", "Nb Sessions",
            "Min", "Max", "Template/Golden Image", "Snapshot", "Datastore"
        ])
        for p in pools:
            row = add_data_row(ws, row, [
                p.get("Nom"), p.get("NomAffichage"), p.get("Type"), p.get("Source"),
                p.get("Protocole"), p.get("Statut"), p.get("NbMachines"), p.get("NbSessions"),
                p.get("MinMachines"), p.get("MaxMachines"), p.get("Template"),
                p.get("TemplateSnapshot"), p.get("Datastore")
            ])

    farms = safe_list(hzn_data, "FarmsRDS")
    if farms:
        row += 1
        row = add_section_header(ws, row, f"Farms RDS ({len(farms)})", 12)
        row = add_table_headers(ws, row, ["Nom", "Affichage", "Type", "Statut", "Nb Serveurs", "Min", "Max"])
        for f in farms:
            row = add_data_row(ws, row, [
                f.get("Nom"), f.get("NomAffichage"), f.get("Type"),
                f.get("Statut"), f.get("NbServeurs"), f.get("MinServeurs"), f.get("MaxServeurs")
            ])

    set_col_widths(ws, {"A": 26, "B": 24, "C": 14, "D": 16, "E": 14, "F": 8, "G": 12, "H": 12, "I": 8, "J": 8, "K": 34, "L": 28, "M": 30})
    freeze(ws, "A4")

def build_sheet_horizon_machines(wb, hzn_data):
    ws = wb.create_sheet("🖥 Horizon - Machines")
    ws.sheet_view.showGridLines = False
    row = add_title_row(ws, "VMWARE HORIZON — Inventaire des machines VDI", "", 10)

    machines = safe_list(hzn_data, "Machines")
    stats = safe_list(hzn_data, "MachinesStats")

    if stats:
        row = add_section_header(ws, row, "Répartition par état", 10)
        row = add_table_headers(ws, row, ["État", "Nombre de machines"])
        total = 0
        for s in stats:
            row = add_data_row(ws, row, [s.get("Name"), s.get("Count")])
            total += s.get("Count", 0) if isinstance(s.get("Count"), int) else 0
        row = add_data_row(ws, row, ["TOTAL", f'=SUM(B{row-len(stats)}:B{row-1})'])
        row += 1

    if machines:
        row = add_section_header(ws, row, f"Détail machines ({len(machines)})", 10)
        row = add_table_headers(ws, row, ["Nom", "Pool", "État", "Session ID", "Utilisateur", "Version Agent", "OS", "IP", "Chemin vCenter"])
        for m in machines:
            etat = m.get("Etat", "")
            hl = "ERROR" if etat in ["ERROR", "AGENT_UNREACHABLE"] else (
                "WARN" if etat in ["MAINTENANCE", "DISABLED"] else None)
            row = add_data_row(ws, row, [
                m.get("Nom"), m.get("Pool"), m.get("Etat"), m.get("SessionID"),
                m.get("UserAssigne"), m.get("TypeAgent"), m.get("OS"),
                m.get("IP"), m.get("vCenterPath")
            ], highlight=hl)

    sessions = safe_list(hzn_data, "Sessions")
    if sessions:
        row += 1
        row = add_section_header(ws, row, f"Sessions actives ({len(sessions)})", 10)
        row = add_table_headers(ws, row, ["Utilisateur", "Machine", "Pool", "Protocole", "Type", "Client", "IP Client", "OS Client", "Début", "État"])
        for s in sessions:
            row = add_data_row(ws, row, [
                s.get("Utilisateur"), s.get("Machine"), s.get("Pool"),
                s.get("Protocole"), s.get("SessionType"), s.get("ClientNom"),
                s.get("ClientIP"), s.get("ClientOS"), s.get("Debut"), s.get("Etat")
            ])

    set_col_widths(ws, {"A": 26, "B": 28, "C": 20, "D": 16, "E": 22, "F": 16, "G": 22, "H": 16, "I": 40})
    freeze(ws, "A4")

# ═════════════════════════════════════════════════════
# FEUILLE : VSPHERE
# ═════════════════════════════════════════════════════
def build_sheet_vsphere(wb, vs_data):
    ws = wb.create_sheet("⚡ vSphere - Clusters")
    ws.sheet_view.showGridLines = False
    row = add_title_row(ws, "VSPHERE — Clusters & Hosts ESXi", "", 14)

    vc = vs_data.get("vCenter", {})
    if vc:
        row = add_kv_section(ws, row, vc, "Informations vCenter", 14)

    clusters = safe_list(vs_data, "Clusters")
    if clusters:
        row = add_section_header(ws, row, f"Clusters vSphere ({len(clusters)})", 14)
        row = add_table_headers(ws, row, [
            "Nom", "Datacenter", "Nb Hosts", "Nb VMs", "DRS", "Mode DRS",
            "HA", "Admission Ctrl", "vSAN", "EVC", "CPU Total (GHz)",
            "RAM Total (GB)", "CPU Usage (%)", "RAM Usage (%)"
        ])
        for c in clusters:
            cpu_pct = c.get("CPUUsage_Pct", 0)
            ram_pct = c.get("RAMUsage_Pct", 0)
            hl = "ERROR" if (cpu_pct > 85 or ram_pct > 85) else ("WARN" if (cpu_pct > 70 or ram_pct > 70) else None)
            row = add_data_row(ws, row, [
                c.get("Name"), c.get("Datacenter"), c.get("NbHosts"), c.get("NbVMs"),
                c.get("DRS"), c.get("DRSMode"), c.get("HA"), c.get("HAAdmissionControl"),
                c.get("vSAN"), c.get("EVC"), c.get("CPUTotal_GHz"),
                c.get("RAMTotal_GB"), cpu_pct, ram_pct
            ], highlight=hl)

    hosts = safe_list(vs_data, "HostsESXi")
    if hosts:
        row += 1
        row = add_section_header(ws, row, f"Hosts ESXi ({len(hosts)})", 14)
        row = add_table_headers(ws, row, [
            "Nom", "Cluster", "Version", "Build", "État", "Maintenance",
            "Sockets", "Cœurs", "CPU (MHz)", "RAM (GB)", "RAM utilisée (GB)",
            "Nb VMs", "Uptime (j)", "HT", "IP Mgmt", "IP vMotion", "IP vSAN"
        ])
        for h in hosts:
            hl = "ERROR" if h.get("Etat") not in ["Connected", None, ""] else (
                "WARN" if str(h.get("Maintenance")) == "True" else None)
            row = add_data_row(ws, row, [
                h.get("Name"), h.get("Cluster"), h.get("Version"), h.get("Build"),
                h.get("Etat"), h.get("Maintenance"), h.get("CPU_Sockets"),
                h.get("CPU_Cores"), h.get("CPU_Mhz"), h.get("RAM_GB"),
                h.get("RAMUsed_GB"), h.get("NbVMs"), h.get("Uptime_Jours"),
                h.get("HyperThreading"), h.get("IP_Management"),
                h.get("IP_vMotion"), h.get("IP_vSAN")
            ], highlight=hl)

    set_col_widths(ws, {
        "A": 26, "B": 18, "C": 10, "D": 10, "E": 12, "F": 12,
        "G": 8, "H": 8, "I": 12, "J": 10, "K": 14, "L": 8,
        "M": 10, "N": 8, "O": 16, "P": 16, "Q": 16
    })
    freeze(ws, "A4")

def build_sheet_vsphere_storage(wb, vs_data):
    ws = wb.create_sheet("⚡ vSphere - Storage")
    ws.sheet_view.showGridLines = False
    row = add_title_row(ws, "VSPHERE — Datastores & Templates/Golden Images", "", 10)

    ds = safe_list(vs_data, "Datastores")
    if ds:
        row = add_section_header(ws, row, f"Datastores ({len(ds)})", 10)
        row = add_table_headers(ws, row, ["Nom", "Type", "Capacité (GB)", "Libre (GB)", "Utilisé (%)", "Nb VMs", "État", "Hosts"])
        for d in sorted(ds, key=lambda x: float(x.get("UsedPct", 0)) if x.get("UsedPct") else 0, reverse=True):
            used = d.get("UsedPct", 0)
            hl = "ERROR" if (isinstance(used, (int,float)) and used > 85) else (
                "WARN" if (isinstance(used, (int,float)) and used > 70) else None)
            row = add_data_row(ws, row, [
                d.get("Name"), d.get("Type"), d.get("CapacityGB"), d.get("FreeGB"),
                d.get("UsedPct"), d.get("NbVMs"), d.get("Accessible"), d.get("Hosts")
            ], highlight=hl)

    templates = safe_list(vs_data, "Templates")
    golden = safe_list(vs_data, "GoldenImages")
    if templates or golden:
        row += 1
        row = add_section_header(ws, row, f"Templates & Golden Images ({len(templates)+len(golden)})", 10)
        row = add_table_headers(ws, row, ["Nom", "Type", "OS", "CPU", "RAM (GB)", "Disques (GB)", "Datastore", "Snapshot", "Date Snapshot"])
        for t in templates:
            row = add_data_row(ws, row, [t.get("Name"), "Template", t.get("OS"), t.get("CPU"), t.get("RAM_GB"), t.get("Disques_GB"), t.get("Datastore"), "", ""])
        for g in golden:
            row = add_data_row(ws, row, [g.get("Name"), "Golden Image (IC)", g.get("OS"), g.get("CPU"), g.get("RAM_GB"), "", "", g.get("Snapshot"), g.get("SnapshotDate")])

    set_col_widths(ws, {"A": 32, "B": 12, "C": 38, "D": 8, "E": 12, "F": 14, "G": 12, "H": 42, "I": 22})
    freeze(ws, "A4")

# ═════════════════════════════════════════════════════
# FEUILLE : RÉSEAU
# ═════════════════════════════════════════════════════
def build_sheet_network(wb, net_data):
    ws = wb.create_sheet("🌐 Réseau DNS-DHCP")
    ws.sheet_view.showGridLines = False
    row = add_title_row(ws, "RÉSEAU — DNS, DHCP, Certificats, NTP, Proxy", "", 10)

    nics = safe_list(net_data, "NICsLocaux")
    if nics:
        row = add_section_header(ws, row, f"Interfaces réseau locales ({len(nics)})", 10)
        row = add_table_headers(ws, row, ["Interface", "Description", "MAC", "Vitesse", "IP", "Masque", "Passerelle", "DNS", "MTU", "VLAN"])
        for n in nics:
            row = add_data_row(ws, row, [
                n.get("Interface"), n.get("Description"), n.get("MAC"), n.get("Vitesse"),
                n.get("IP"), n.get("Masque"), n.get("Passerelle"), n.get("DNS"),
                n.get("MTU"), n.get("VLAN")
            ])

    certs = safe_list(net_data, "Certificats")
    if certs:
        row += 1
        row = add_section_header(ws, row, f"Certificats SSL ({len(certs)})", 10)
        row = add_table_headers(ws, row, ["Sujet", "Emetteur", "Expire", "Jours restants", "Alerte", "Thumbprint", "SAN"])
        for c in sorted(certs, key=lambda x: x.get("JoursRestants", 9999) if isinstance(x.get("JoursRestants"), int) else 9999):
            days = c.get("JoursRestants", 9999)
            hl = "ERROR" if (isinstance(days, int) and days < 30) else (
                "WARN" if (isinstance(days, int) and days < 60) else None)
            row = add_data_row(ws, row, [
                c.get("Sujet"), c.get("Emetteur"), c.get("Expire"),
                c.get("JoursRestants"), c.get("Alerte"), c.get("Thumbprint"), c.get("SAN")
            ], highlight=hl)

    ntp = net_data.get("NTP", {})
    if ntp:
        row += 1
        row = add_kv_section(ws, row, ntp, "Configuration NTP", 10)

    proxy = net_data.get("Proxy", {})
    if proxy:
        row = add_kv_section(ws, row, proxy, "Configuration Proxy", 10)

    fw = safe_list(net_data, "FirewallReglesVDI")
    if fw:
        row += 1
        row = add_section_header(ws, row, f"Règles pare-feu VDI ({len(fw)})", 10)
        row = add_table_headers(ws, row, ["Nom", "Direction", "Action", "Protocole", "Port Local", "Port Distant", "Profil", "Description"])
        for f in fw:
            row = add_data_row(ws, row, [
                f.get("DisplayName"), f.get("Direction"), f.get("Action"),
                f.get("Protocol"), f.get("LocalPort"), f.get("RemotePort"),
                f.get("Profile"), f.get("Description")
            ])

    set_col_widths(ws, {"A": 36, "B": 36, "C": 14, "D": 14, "E": 14, "F": 14, "G": 14, "H": 40})
    freeze(ws, "A4")

# ═════════════════════════════════════════════════════
# FEUILLE : PORTS & PROTOCOLES VDI (référence statique)
# ═════════════════════════════════════════════════════
def build_sheet_ports(wb):
    ws = wb.create_sheet("📡 Ports VDI Référence")
    ws.sheet_view.showGridLines = False
    row = add_title_row(ws, "RÉFÉRENCE — Ports & Protocoles VMware Horizon / MECM", "Tableau de référence fixe", 7)

    ports = [
        # Horizon Connection Server
        ("Horizon CS → CS (réplication)",    "TCP", "4001, 4100, 4101", "Connection Server ↔ Connection Server", "Interne"),
        ("Client → Connection Server (HTTPS)","TCP", "443",              "Blast Extreme, HTML Access, PCoIP gateway", "Externe"),
        ("Client → Connection Server (HTTP)", "TCP", "80",               "Redirect vers HTTPS", "Externe"),
        ("PCoIP (UDP)",                        "UDP", "4172",             "Protocole PCoIP client → agent", "Externe"),
        ("PCoIP (TCP)",                        "TCP", "4172",             "Protocole PCoIP fallback TCP", "Externe"),
        ("Blast Extreme (HTTPS)",             "TCP", "8443",             "Blast Extreme client → agent", "Externe"),
        ("Blast Extreme (UDP)",               "UDP", "8443",             "Blast Extreme UDP", "Externe"),
        ("CDP (RDP)",                          "TCP", "3389",             "RDP direct", "Externe"),
        ("MMR / CDR",                          "TCP", "9427",             "Multimedia redirection", "Interne"),
        ("USB redirection",                    "TCP", "32111",            "Redirection USB client", "Interne"),
        ("JMXMP (monitoring)",                 "TCP", "6972",             "Connection Server monitoring", "Interne"),
        ("Horizon View Composer",             "TCP", "18443",            "vSphere API for linked clones", "Interne"),
        # Horizon Agent
        ("Agent → CS (heartbeat)",            "TCP", "4001",             "Agent → Connection Server", "Interne"),
        ("Blast Agent",                        "TCP", "22443",            "Client direct Blast (bypass CS)", "Optionnel"),
        # vCenter / ESXi
        ("vCenter HTTPS",                     "TCP", "443",              "Client → vCenter API", "Interne"),
        ("vCenter SDK",                        "TCP", "80",               "HTTP redirect", "Interne"),
        ("ESXi Management",                   "TCP", "443",              "ESXi HTTPS management", "Interne"),
        ("ESXi SSH",                           "TCP", "22",               "ESXi SSH (désactivé en prod)", "Interne"),
        ("vMotion",                            "TCP/UDP", "8000",         "vMotion traffic", "Interne"),
        ("NFC (Storage vMotion)",             "TCP", "902",              "Stockage vMotion", "Interne"),
        # MECM
        ("MECM Client → MP",                  "TCP", "80, 443",          "Management Point HTTP/HTTPS", "Interne"),
        ("MECM Client → DP",                  "TCP", "80, 443",          "Distribution Point", "Interne"),
        ("MECM Console → Site Server",        "TCP", "2179, 10123",      "Console admin → Site Server", "Interne"),
        ("MECM Wake-On-LAN",                  "UDP", "9",                "Wake On LAN", "Interne"),
        ("MECM PXE (TFTP)",                  "UDP", "69",               "PXE Boot TFTP", "Interne"),
        ("MECM PXE (DHCP)",                  "UDP", "67, 68",           "PXE DHCP Bootstrap", "Interne"),
        # AD / DNS / Kerberos
        ("LDAP",                              "TCP/UDP", "389",          "Active Directory LDAP", "Interne"),
        ("LDAPS",                             "TCP", "636",              "Active Directory LDAPS", "Interne"),
        ("Kerberos",                          "TCP/UDP", "88",           "Authentification Kerberos", "Interne"),
        ("DNS",                               "TCP/UDP", "53",           "Résolution DNS", "Interne"),
        ("SMB/CIFS",                          "TCP", "445",              "Partages fichiers", "Interne"),
        ("RPC Endpoint Mapper",              "TCP", "135",              "WMI / RPC", "Interne"),
        ("NTP",                               "UDP", "123",              "Synchronisation temps", "Interne"),
        ("WinRM HTTP",                        "TCP", "5985",             "Windows Remote Management", "Interne"),
        ("WinRM HTTPS",                       "TCP", "5986",             "Windows Remote Management sécurisé", "Interne"),
    ]

    row = add_section_header(ws, row, "Ports & Protocoles de référence", 7)
    row = add_table_headers(ws, row, ["Service / Flux", "Proto", "Port(s)", "Description", "Contexte"])
    for p in ports:
        row = add_data_row(ws, row, list(p))

    set_col_widths(ws, {"A": 36, "B": 10, "C": 18, "D": 44, "E": 12})
    freeze(ws, "A4")

# ═════════════════════════════════════════════════════
# MAIN
# ═════════════════════════════════════════════════════
def main():
    parser = argparse.ArgumentParser(description="VDI OpsKit - Excel Generator")
    parser.add_argument("--json",   required=False, default=None, help="Fichier JSON de collecte")
    parser.add_argument("--output", required=False, default="VDI_OpsKit.xlsx", help="Fichier Excel de sortie")
    parser.add_argument("--demo",   action="store_true", help="Générer avec données de démonstration")
    args = parser.parse_args()

    # Chargement données
    if args.json and os.path.exists(args.json):
        with open(args.json, encoding="utf-8") as f:
            data = json.load(f)
        print(f"[OK] JSON chargé : {args.json}")
    else:
        # Données de démo si aucun JSON
        print("[INFO] Aucun JSON fourni — génération avec données de démo")
        data = {
            "AD": {
                "Domaine": {
                    "NomDNS": "corp.local", "NomNetBIOS": "CORP",
                    "NiveauFonctionnel": "Windows2019Domain", "Forest": "corp.local",
                    "PDCEmulator": "DC01.corp.local", "RIDMaster": "DC01.corp.local",
                    "InfrastructureMaster": "DC01.corp.local", "SchemaMaster": "DC01.corp.local",
                    "NamingMaster": "DC01.corp.local", "DistinguishedName": "DC=corp,DC=local",
                    "SID": "S-1-5-21-XXXXXXXXX"
                },
                "ControleursDeDomaine": [
                    {"Name":"DC01","IPv4Address":"10.0.1.10","Site":"Paris","IsGlobalCatalog":"True","IsReadOnly":"False","OperatingSystem":"Windows Server 2022","OperatingSystemVersion":"10.0 (20348)","FSMO":"PDC, RID, Infrastructure","Enabled":"True","Ping":"True"},
                    {"Name":"DC02","IPv4Address":"10.0.1.11","Site":"Paris","IsGlobalCatalog":"True","IsReadOnly":"False","OperatingSystem":"Windows Server 2022","OperatingSystemVersion":"10.0 (20348)","FSMO":"","Enabled":"True","Ping":"True"},
                ],
                "SitesAD": [
                    {"Name":"Paris","Subnets":"10.0.0.0/16 | 10.1.0.0/24","DistinguishedName":"CN=Paris,CN=Sites,..."},
                    {"Name":"Lyon","Subnets":"10.2.0.0/24","DistinguishedName":"CN=Lyon,CN=Sites,..."},
                ],
                "GPOs": [
                    {"DisplayName":"VDI - Config Bureau","Id":"xxxxxxxx-1111","GpoStatus":"AllSettingsEnabled","CreationDate":"2023-01-10","ModifiedDate":"2024-06-15","WMIFilter":"","LinkedOUs":"OU=VDI,DC=corp,DC=local"},
                    {"DisplayName":"VDI - Sécurité","Id":"xxxxxxxx-2222","GpoStatus":"AllSettingsEnabled","CreationDate":"2023-02-01","ModifiedDate":"2024-07-01","WMIFilter":"","LinkedOUs":"OU=VDI,DC=corp,DC=local"},
                    {"DisplayName":"MECM Client Settings","Id":"xxxxxxxx-3333","GpoStatus":"AllSettingsEnabled","CreationDate":"2022-11-01","ModifiedDate":"2024-05-20","WMIFilter":"","LinkedOUs":"OU=Computers,DC=corp,DC=local"},
                ],
                "ComptesService": [
                    {"SamAccountName":"svc-horizon","DisplayName":"Horizon Service Account","Description":"Compte service VMware Horizon","Enabled":"True","PasswordLastSet":"2024-03-01","PasswordNeverExpires":"False","LastLogon":"2025-03-28","Expiration":None},
                    {"SamAccountName":"svc-mecm","DisplayName":"MECM Service Account","Description":"Compte service MECM","Enabled":"True","PasswordLastSet":"2024-01-15","PasswordNeverExpires":"False","LastLogon":"2025-03-29","Expiration":None},
                    {"SamAccountName":"svc-vcenter","DisplayName":"vCenter Service Account","Description":"Compte service vCenter","Enabled":"True","PasswordLastSet":"2023-12-01","PasswordNeverExpires":"False","LastLogon":"2025-03-29","Expiration":"2026-04-01"},
                ],
            },
            "MECM": {
                "Site": {"SiteCode":"P01","SiteName":"Paris Production","Version":"5.00.9122","BuildNumber":"9122","ServerName":"MECM-SRV01.corp.local","Type":"Primaire","SQLServer":"MECM-SQL01\\SCCM"},
                "RolesSite": [
                    {"Serveur":"MECM-SRV01.corp.local","Roles":"SMS_SITE_SERVER | SMS_MANAGEMENT_POINT | SMS_DISTRIBUTION_POINT","SiteCode":"P01","LastOnline":"2025-03-30 06:00"},
                    {"Serveur":"MECM-DP01.corp.local","Roles":"SMS_DISTRIBUTION_POINT | SMS_PXE_POINT","SiteCode":"P01","LastOnline":"2025-03-30 06:00"},
                ],
                "CollectionsVDI": [
                    {"Name":"VDI - All Machines","CollectionID":"P0100001","Comment":"Toutes les machines VDI","MemberCount":245,"LimitToCollectionName":"All Systems","RefreshType":"Périodique+Incrémental","LastRefresh":"2025-03-30 04:00","QueryRule":"select * from SMS_R_System where SMS_R_System.SystemOUName like '%VDI%'"},
                    {"Name":"VDI - Windows 11","CollectionID":"P0100002","Comment":"VMs Windows 11","MemberCount":190,"LimitToCollectionName":"VDI - All Machines","RefreshType":"Incrémental","LastRefresh":"2025-03-30 04:05","QueryRule":"... where OperatingSystemNameandVersion like '%Windows 11%'"},
                ],
                "TaskSequences": [
                    {"Name":"Deploy VDI W11 - Instant Clone","SequenceID":"TS001","Modifie":"2025-01-15","BootImage":"BIM001","Deploiements":3,"PackageID":"P0100020"},
                    {"Name":"Refresh Golden Image W11","SequenceID":"TS002","Modifie":"2025-02-01","BootImage":"BIM001","Deploiements":1,"PackageID":"P0100021"},
                ],
                "MaintenanceWindows": [
                    {"Collection":"VDI - All Machines","Name":"MW Nuit Semaine","IsEnabled":"True","DurationHours":4,"Recurrence":"Lun-Ven 02:00","Type":"General"},
                ],
            },
            "Horizon": {
                "Environnement": {"Version":"2312","Build":"8.12.0.XXXXX","ProductName":"VMware Horizon","UUID":"xxxxxxxx","FQDNServeur":"hzn-cs01.corp.local","PodNom":"POD-Paris"},
                "ConnectionServers": [
                    {"Nom":"HZN-CS01","Version":"2312","Statut":"OK","SessionsActives":42,"IP":"10.0.2.10","Role":"Standard","CertExpiry":"2026-06-15"},
                    {"Nom":"HZN-CS02","Version":"2312","Statut":"OK","SessionsActives":38,"IP":"10.0.2.11","Role":"Standard","CertExpiry":"2026-06-15"},
                ],
                "DesktopPools": [
                    {"Nom":"POOL-WIN11-IC","NomAffichage":"Bureau Windows 11","Type":"AUTOMATED","Source":"INSTANT_CLONE","Protocole":"BLAST","Statut":"True","NbMachines":100,"NbSessions":42,"MinMachines":20,"MaxMachines":100,"Template":"/Datacenter/vm/Templates","TemplateSnapshot":"Snap_2025-03-01","Datastore":"DS-VDI-01"},
                    {"Nom":"POOL-WIN11-MANUAL","NomAffichage":"Bureau dédié","Type":"MANUAL","Source":"FULL_CLONE","Protocole":"BLAST","Statut":"True","NbMachines":20,"NbSessions":18,"MinMachines":None,"MaxMachines":None,"Template":None,"TemplateSnapshot":None,"Datastore":"DS-VDI-02"},
                ],
                "FarmsRDS": [
                    {"Nom":"FARM-RDS-APPS","NomAffichage":"Applications publiées","Type":"AUTOMATED","Statut":"Active","NbServeurs":4,"MinServeurs":2,"MaxServeurs":8},
                ],
                "Machines": [
                    {"Nom":"VDI-IC-001","Pool":"POOL-WIN11-IC","Etat":"CONNECTED","SessionID":"sess-001","UserAssigne":"jdupont","TypeAgent":"2312","OS":"Windows 11","IP":"10.0.5.101","vCenterPath":"/DC/vm/VDI/VDI-IC-001"},
                    {"Nom":"VDI-IC-002","Pool":"POOL-WIN11-IC","Etat":"AVAILABLE","SessionID":None,"UserAssigne":None,"TypeAgent":"2312","OS":"Windows 11","IP":"10.0.5.102","vCenterPath":"/DC/vm/VDI/VDI-IC-002"},
                    {"Nom":"VDI-IC-003","Pool":"POOL-WIN11-IC","Etat":"MAINTENANCE","SessionID":None,"UserAssigne":None,"TypeAgent":"2312","OS":"Windows 11","IP":"10.0.5.103","vCenterPath":"/DC/vm/VDI/VDI-IC-003"},
                ],
                "MachinesStats": [
                    {"Name":"CONNECTED","Count":42},{"Name":"AVAILABLE","Count":55},
                    {"Name":"MAINTENANCE","Count":3},{"Name":"ERROR","Count":0},
                ],
                "Sessions": [
                    {"Utilisateur":"jdupont","Machine":"VDI-IC-001","Pool":"POOL-WIN11-IC","Protocole":"BLAST","SessionType":"DESKTOP","ClientNom":"LAPTOP-JDUPONT","ClientIP":"192.168.1.50","ClientOS":"Windows 11","Debut":"2025-03-30 08:32","Etat":"CONNECTED"},
                ],
            },
            "vSphere": {
                "vCenter": {"Serveur":"vcenter.corp.local","Version":"8.0.2","Build":"23319993","Producteur":"VMware vCenter Server","APIVersion":"8.0.2.0","ConnectedAs":"svc-vcenter@corp.local"},
                "Clusters": [
                    {"Name":"CLS-VDI-01","Datacenter":"DC-Paris","NbHosts":4,"NbVMs":145,"DRS":"True","DRSMode":"FullyAutomated","HA":"True","HAAdmissionControl":"True","vSAN":"False","EVC":"intel-icelake","CPUTotal_GHz":384,"RAMTotal_GB":1536,"CPUUsage_Pct":38.5,"RAMUsage_Pct":72.1},
                    {"Name":"CLS-INF-01","Datacenter":"DC-Paris","NbHosts":3,"NbVMs":48,"DRS":"True","DRSMode":"FullyAutomated","HA":"True","HAAdmissionControl":"True","vSAN":"True","EVC":"intel-icelake","CPUTotal_GHz":192,"RAMTotal_GB":768,"CPUUsage_Pct":25.3,"RAMUsage_Pct":55.8},
                ],
                "HostsESXi": [
                    {"Name":"esxi01.corp.local","Cluster":"CLS-VDI-01","Version":"8.0.2","Build":"23305546","Etat":"Connected","Maintenance":"False","CPU_Sockets":2,"CPU_Cores":40,"CPU_Mhz":96000,"RAM_GB":384,"RAMUsed_GB":278,"NbVMs":38,"Uptime_Jours":45,"HyperThreading":"True","IP_Management":"10.0.3.11","IP_vMotion":"10.0.4.11","IP_vSAN":None},
                    {"Name":"esxi02.corp.local","Cluster":"CLS-VDI-01","Version":"8.0.2","Build":"23305546","Etat":"Connected","Maintenance":"False","CPU_Sockets":2,"CPU_Cores":40,"CPU_Mhz":96000,"RAM_GB":384,"RAMUsed_GB":295,"NbVMs":40,"Uptime_Jours":45,"HyperThreading":"True","IP_Management":"10.0.3.12","IP_vMotion":"10.0.4.12","IP_vSAN":None},
                ],
                "Datastores": [
                    {"Name":"DS-VDI-01","Type":"NFS","CapacityGB":10240,"FreeGB":3200,"UsedPct":68.8,"NbVMs":80,"Accessible":"Accessible","Hosts":"esxi01 | esxi02"},
                    {"Name":"DS-VDI-02","Type":"NFS","CapacityGB":10240,"FreeGB":1100,"UsedPct":89.2,"NbVMs":65,"Accessible":"Accessible","Hosts":"esxi01 | esxi02"},
                    {"Name":"DS-INFRA-VSAN","Type":"vSAN","CapacityGB":20480,"FreeGB":12000,"UsedPct":41.4,"NbVMs":48,"Accessible":"Accessible","Hosts":"esxi03 | esxi04 | esxi05"},
                ],
                "Templates": [
                    {"Name":"TMPL-W11-ENT-2025Q1","OS":"Windows 11 Enterprise","CPU":4,"RAM_GB":8,"Disques_GB":80,"Datastore":"DS-INFRA-VSAN"},
                ],
                "GoldenImages": [
                    {"Name":"GOLDEN-W11-IC","OS":"Windows 11 Enterprise","CPU":4,"RAM_GB":8,"Snapshot":"SNAP-2025-03-01","SnapshotDate":"2025-03-01 22:00"},
                ],
                "Licences": [
                    {"Produit":"vSphere 8 Enterprise Plus","Cle":"XXXXX-XXXXX-XXXXX","Total":48,"Utilise":7,"Restant":41,"Expiration":"2026-12-31","Type":"Enterprise Plus"},
                    {"Produit":"VMware vSAN 8 Enterprise","Cle":"YYYYY-YYYYY-YYYYY","Total":24,"Utilise":3,"Restant":21,"Expiration":"2026-12-31","Type":"Enterprise"},
                ],
            },
            "Network": {
                "NICsLocaux": [
                    {"Interface":"Ethernet0","Description":"VMXNET3 Ethernet Adapter","MAC":"00-50-56-XX-XX-XX","Vitesse":"10 Gbps","IP":"10.0.2.10","Masque":"24","Passerelle":"10.0.2.1","DNS":"10.0.1.10 | 10.0.1.11","MTU":"1500","VLAN":"100"},
                ],
                "Certificats": [
                    {"Sujet":"CN=hzn-cs01.corp.local","Emetteur":"CN=Corp-CA","Expire":"2026-06-15","JoursRestants":442,"Alerte":"OK","Thumbprint":"A1B2C3...","SAN":"hzn-cs01.corp.local, vdi.corp.local"},
                    {"Sujet":"CN=vcenter.corp.local","Emetteur":"CN=Corp-CA","Expire":"2025-04-20","JoursRestants":21,"Alerte":"ATTENTION < 60j","Thumbprint":"D4E5F6...","SAN":"vcenter.corp.local"},
                ],
                "NTP": {"Configuration":"Type: NT5DS\nNtpServer: 0.fr.pool.ntp.org", "Peers":"Pair: 0.fr.pool.ntp.org\nEtat: Actif", "Status":"Offset: 0.003s\nRéférence: 0.fr.pool.ntp.org"},
                "Proxy": {"ProxyGPO":"proxy.corp.local:8080","ProxyActiveUser":"proxy.corp.local:8080","ProxyEnable":1,"BypassList":"*.corp.local;10.*","AutoConfig":None},
                "FirewallReglesVDI": [
                    {"DisplayName":"Horizon Blast TCP 8443","Direction":"Inbound","Action":"Allow","Protocol":"TCP","LocalPort":"8443","RemotePort":"Any","Profile":"Domain","Description":"Blast Extreme"},
                    {"DisplayName":"PCoIP UDP 4172","Direction":"Inbound","Action":"Allow","Protocol":"UDP","LocalPort":"4172","RemotePort":"Any","Profile":"Domain","Description":"PCoIP Protocol"},
                ],
            }
        }

    wb = Workbook()
    # Supprimer la feuille par défaut
    if "Sheet" in wb.sheetnames:
        del wb["Sheet"]

    print("[INFO] Construction des feuilles Excel...")

    build_sheet_summary(wb, data)

    ad = data.get("AD", {})
    build_sheet_ad(wb, ad)
    build_sheet_gpo(wb, ad)

    mecm = data.get("MECM", {})
    build_sheet_mecm(wb, mecm)

    hzn = data.get("Horizon", {})
    build_sheet_horizon(wb, hzn)
    build_sheet_horizon_machines(wb, hzn)

    vs = data.get("vSphere", {})
    build_sheet_vsphere(wb, vs)
    build_sheet_vsphere_storage(wb, vs)

    net = data.get("Network", {})
    build_sheet_network(wb, net)

    build_sheet_ports(wb)

    wb.save(args.output)
    print(f"[OK] Excel sauvegardé : {args.output}")
    print(f"[OK] Feuilles : {', '.join(wb.sheetnames)}")

if __name__ == "__main__":
    main()
