<#
.SYNOPSIS
    Collecte toutes les informations VMware Horizon VDI.
.DESCRIPTION
    Récupère via API REST Horizon : Connection Servers, Pools de bureaux, Farms RDS,
    Machines, Sessions, vCenter liés, Datastores, Licences
.NOTES
    Requiert : Module VMware.Hv.Helper ou appels REST directs à l'API Horizon 8
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string]$HorizonServer,          # FQDN du Connection Server : ex. "hzn-cs01.domain.local"

    [Parameter(Mandatory)]
    [System.Management.Automation.PSCredential]$HorizonCredential,

    [string]$Domain,                  # ex. "DOMAIN"
    [string]$OutputPath = "$PSScriptRoot\..\output",
    [switch]$ExportJson
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Continue"

function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $color = switch ($Level) { "ERROR" { "Red" } "WARN" { "Yellow" } "OK" { "Green" } default { "Cyan" } }
    Write-Host "[$ts] [$Level] $Message" -ForegroundColor $color
}

function Invoke-HorizonAPI {
    param([string]$Method = "GET", [string]$Endpoint, [object]$Body = $null)
    $uri = "https://$HorizonServer/rest/$Endpoint"
    $params = @{
        Method  = $Method
        Uri     = $uri
        Headers = $script:HorizonHeaders
        ContentType = "application/json"
        SkipCertificateCheck = $true
    }
    if ($Body) { $params["Body"] = ($Body | ConvertTo-Json -Depth 10) }
    try {
        return (Invoke-RestMethod @params)
    } catch {
        Write-Log "API Error [$Endpoint] : $($_.Exception.Message)" "ERROR"
        return $null
    }
}

Write-Log "=== COLLECTE VMWARE HORIZON VDI ===" "OK"

# ─────────────────────────────────────────
# AUTHENTIFICATION API REST Horizon
# ─────────────────────────────────────────
Write-Log "Authentification sur $HorizonServer..."
try {
    $loginBody = @{
        username = $HorizonCredential.UserName
        password = $HorizonCredential.GetNetworkCredential().Password
        domain   = if ($Domain) { $Domain } else { $env:USERDOMAIN }
    }
    $authResult = Invoke-RestMethod -Method POST `
        -Uri "https://$HorizonServer/rest/login" `
        -Body ($loginBody | ConvertTo-Json) `
        -ContentType "application/json" `
        -SkipCertificateCheck
    $script:HorizonHeaders = @{
        Authorization = "Bearer $($authResult.access_token)"
    }
    Write-Log "Authentification réussie. Token valide $($authResult.expiration) sec." "OK"
} catch {
    Write-Log "Échec d'authentification Horizon : $_" "ERROR"
    return
}

$HorizonData = [ordered]@{}

# ─────────────────────────────────────────
# 1. INFORMATIONS ENVIRONNEMENT
# ─────────────────────────────────────────
Write-Log "Collecte des infos environnement Horizon..."
$envInfo = Invoke-HorizonAPI -Endpoint "config/v1/environment-properties"
if ($envInfo) {
    $HorizonData["Environnement"] = [ordered]@{
        Version         = $envInfo.version
        Build           = $envInfo.build
        ProductName     = $envInfo.product_name
        UUID            = $envInfo.uuid
        FQDNServeur     = $HorizonServer
        PodNom          = $envInfo.cluster_name
    }
    Write-Log "Version Horizon : $($envInfo.version)" "OK"
}

# ─────────────────────────────────────────
# 2. CONNECTION SERVERS
# ─────────────────────────────────────────
Write-Log "Collecte des Connection Servers..."
$CSList = Invoke-HorizonAPI -Endpoint "monitor/v1/connection-servers"
if ($CSList) {
    $HorizonData["ConnectionServers"] = $CSList | ForEach-Object {
        [ordered]@{
            Nom             = $_.name
            Version         = $_.version
            Statut          = $_.status
            SessionsActives = $_.session_count
            IP              = $_.server_address
            FQDN            = $_.name
            Role            = $_.cs_replications | ConvertTo-Json -Compress
            CertExpiry      = $_.certificate?.expiration_date
        }
    }
    Write-Log "$($CSList.Count) Connection Server(s) trouvé(s)" "OK"
}

# ─────────────────────────────────────────
# 3. VCENTER LIÉS
# ─────────────────────────────────────────
Write-Log "Collecte des vCenters liés..."
$vCenters = Invoke-HorizonAPI -Endpoint "config/v1/virtual-centers"
if ($vCenters) {
    $HorizonData["vCenters"] = $vCenters | ForEach-Object {
        [ordered]@{
            Serveur         = $_.server_name
            Port            = $_.port
            Utilisateur     = $_.user_name
            Version         = $_.version
            APIVersion      = $_.api_version
            Statut          = $_.status
            ID              = $_.id
        }
    }
    Write-Log "$($vCenters.Count) vCenter(s) trouvé(s)" "OK"
}

# ─────────────────────────────────────────
# 4. POOLS DE BUREAUX VIRTUELS
# ─────────────────────────────────────────
Write-Log "Collecte des Desktop Pools..."
$Pools = Invoke-HorizonAPI -Endpoint "inventory/v7/desktop-pools"
if ($Pools) {
    $HorizonData["DesktopPools"] = $Pools | ForEach-Object {
        $poolDetail = Invoke-HorizonAPI -Endpoint "inventory/v7/desktop-pools/$($_.id)"
        [ordered]@{
            Nom                 = $_.name
            NomAffichage        = $_.display_name
            Description         = $_.description
            Type                = $_.type  # AUTOMATED, MANUAL, RDS
            Source              = $_.source # INSTANT_CLONE, LINKED_CLONE, FULL_CLONE
            Protocole           = $_.default_display_protocol
            Statut              = $_.enabled
            NbMachines          = $_.machine_count
            NbSessions          = $_.session_count
            vCenterID           = $_.vcenter_id
            TemplateSnapshot    = $poolDetail?.automated_desktop_pool_data?.image_source?.snapshot_path
            Template            = $poolDetail?.automated_desktop_pool_data?.image_source?.vm_folder_path
            MinMachines         = $poolDetail?.automated_desktop_pool_data?.vm_naming_settings?.naming_settings?.min_num_machines
            MaxMachines         = $poolDetail?.automated_desktop_pool_data?.vm_naming_settings?.naming_settings?.max_num_machines
            Datastore           = $poolDetail?.automated_desktop_pool_data?.storage_settings?.datastores[0]?.datastore_path
            ResAffectee         = ($_.entitlements | ConvertTo-Json -Compress)
        }
    }
    Write-Log "$($Pools.Count) Desktop Pool(s) trouvé(s)" "OK"
}

# ─────────────────────────────────────────
# 5. FARMS RDS
# ─────────────────────────────────────────
Write-Log "Collecte des RDS Farms..."
$Farms = Invoke-HorizonAPI -Endpoint "inventory/v7/farms"
if ($Farms) {
    $HorizonData["FarmsRDS"] = $Farms | ForEach-Object {
        [ordered]@{
            Nom             = $_.name
            NomAffichage    = $_.display_name
            Type            = $_.type  # AUTOMATED, MANUAL
            Statut          = $_.access_group_id
            NbServeurs      = $_.rds_server_count
            vCenterID       = $_.vcenter_id
            MinServeurs     = $_.automated_farm_data?.vm_naming_settings?.naming_settings?.min_ready_vms_on_vdi_desktop
            MaxServeurs     = $_.automated_farm_data?.vm_naming_settings?.naming_settings?.max_machines
        }
    }
    Write-Log "$($Farms.Count) RDS Farm(s) trouvée(s)" "OK"
}

# ─────────────────────────────────────────
# 6. MACHINES VDI (état & distribution)
# ─────────────────────────────────────────
Write-Log "Collecte des machines VDI..."
$Machines = Invoke-HorizonAPI -Endpoint "inventory/v7/machines"
if ($Machines) {
    $HorizonData["Machines"] = $Machines | Select-Object @(
        @{N="Nom";E={ $_.name }},
        @{N="Pool";E={ $_.desktop_pool_id }},
        @{N="Etat";E={ $_.state }},
        @{N="SessionID";E={ $_.session_id }},
        @{N="UserAssigne";E={ $_.user_id }},
        @{N="TypeAgent";E={ $_.agent_version }},
        @{N="OS";E={ $_.operating_system }},
        @{N="IP";E={ $_.ip_v4 }},
        @{N="vCenterPath";E={ $_.managed_machine_data?.virtual_center_managed_machine_data?.path }}
    )
    $stateStats = $Machines | Group-Object state | Select-Object Name, Count | Sort-Object Count -Descending
    $HorizonData["MachinesStats"] = $stateStats
    Write-Log "$($Machines.Count) machine(s) VDI trouvée(s)" "OK"
}

# ─────────────────────────────────────────
# 7. SESSIONS ACTIVES
# ─────────────────────────────────────────
Write-Log "Collecte des sessions actives..."
$Sessions = Invoke-HorizonAPI -Endpoint "inventory/v1/sessions"
if ($Sessions) {
    $HorizonData["Sessions"] = $Sessions | Select-Object @(
        @{N="Utilisateur";E={ $_.user_name }},
        @{N="Machine";E={ $_.machine_name }},
        @{N="Pool";E={ $_.desktop_pool_id }},
        @{N="Protocole";E={ $_.protocol }},
        @{N="SessionType";E={ $_.session_type }},
        @{N="ClientNom";E={ $_.client_name }},
        @{N="ClientIP";E={ $_.client_address }},
        @{N="ClientOS";E={ $_.client_platform }},
        @{N="Debut";E={ $_.start_time }},
        @{N="Etat";E={ $_.session_state }}
    )
    Write-Log "$($Sessions.Count) session(s) active(s)" "OK"
}

# ─────────────────────────────────────────
# 8. ACCESS GROUPS
# ─────────────────────────────────────────
Write-Log "Collecte des Access Groups..."
$AccessGroups = Invoke-HorizonAPI -Endpoint "config/v1/access-groups"
if ($AccessGroups) {
    $HorizonData["AccessGroups"] = $AccessGroups | Select-Object @(
        @{N="Nom";E={ $_.name }},
        @{N="Description";E={ $_.description }},
        @{N="Parent";E={ $_.parent_id }},
        @{N="ID";E={ $_.id }}
    )
    Write-Log "$($AccessGroups.Count) Access Group(s) trouvé(s)" "OK"
}

# ─────────────────────────────────────────
# 9. INSTANT CLONE ENGINE ACCOUNTS
# ─────────────────────────────────────────
Write-Log "Collecte des Instant Clone Engine Accounts..."
$ICAccounts = Invoke-HorizonAPI -Endpoint "config/v1/instant-clone-domain-accounts"
if ($ICAccounts) {
    $HorizonData["InstantCloneAccounts"] = $ICAccounts | Select-Object @(
        @{N="Username";E={ $_.user_name }},
        @{N="Domain";E={ $_.ad_domain_id }},
        @{N="ID";E={ $_.id }}
    )
}

# Déconnexion
try {
    Invoke-RestMethod -Method POST -Uri "https://$HorizonServer/rest/logout" `
        -Headers $script:HorizonHeaders -ContentType "application/json" `
        -SkipCertificateCheck | Out-Null
    Write-Log "Déconnexion Horizon OK" "OK"
} catch {}

if ($ExportJson) {
    if (-not (Test-Path $OutputPath)) { New-Item -ItemType Directory -Path $OutputPath | Out-Null }
    $HorizonData | ConvertTo-Json -Depth 10 | Out-File "$OutputPath\Horizon_Info.json" -Encoding UTF8
    Write-Log "Export JSON : $OutputPath\Horizon_Info.json" "OK"
}

Write-Log "=== COLLECTE HORIZON TERMINÉE ===" "OK"
return $HorizonData
