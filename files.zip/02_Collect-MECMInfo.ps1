#Requires -Modules ConfigurationManager
<#
.SYNOPSIS
    Collecte toutes les informations MECM/SCCM nécessaires à la gestion opérationnelle VDI.
.DESCRIPTION
    Récupère : Site, Rôles, Collections VDI, Applications, Packages, Séquences de tâches,
               Limites, Distribution Points, Software Updates
#>

[CmdletBinding()]
param(
    [string]$SiteCode,          # Ex: "P01"
    [string]$SiteServer,        # Ex: "MECM-SRVR.domain.local"
    [string]$OutputPath = "$PSScriptRoot\..\output",
    [switch]$ExportJson
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Continue"

function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $color = switch ($Level) { "ERROR" { "Red" } "WARN" { "Yellow" } "OK" { "Green" } default { "Cyan" } }
    Write-Host "[$ts] [$Level] $Message" -ForegroundColor $color
}

Write-Log "=== COLLECTE MECM/SCCM ===" "OK"

# Auto-detect Site Code si non fourni
if (-not $SiteCode) {
    try {
        $SiteCode = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\SMS\Identification" -ErrorAction Stop)."Site Code"
        Write-Log "Site Code détecté : $SiteCode" "OK"
    } catch {
        Write-Log "Impossible de détecter le Site Code. Spécifier -SiteCode" "ERROR"
        return
    }
}
if (-not $SiteServer) {
    try {
        $SiteServer = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\SMS\Identification" -ErrorAction Stop)."Site Server"
        Write-Log "Site Server détecté : $SiteServer" "OK"
    } catch {
        $SiteServer = $env:COMPUTERNAME
    }
}

# Connexion au provider MECM
try {
    $initParams = @{ SiteCode = $SiteCode; SiteServer = $SiteServer }
    if (-not (Get-Module ConfigurationManager)) { Import-Module "$($ENV:SMS_ADMIN_UI_PATH)\..\ConfigurationManager.psd1" }
    if (-not (Get-PSDrive -Name $SiteCode -ErrorAction SilentlyContinue)) {
        New-PSDrive -Name $SiteCode -PSProvider CMSite -Root $SiteServer | Out-Null
    }
    Push-Location "$($SiteCode):\"
    Write-Log "Connecté au site MECM $SiteCode sur $SiteServer" "OK"
} catch {
    Write-Log "Erreur connexion MECM : $_" "ERROR"
    return
}

$MECMData = [ordered]@{}

# ─────────────────────────────────────────
# 1. INFORMATIONS SITE
# ─────────────────────────────────────────
Write-Log "Collecte des informations site MECM..."
try {
    $site = Get-CMSite -SiteCode $SiteCode
    $MECMData["Site"] = [ordered]@{
        SiteCode        = $site.SiteCode
        SiteName        = $site.SiteName
        Version         = $site.Version
        BuildNumber     = $site.BuildNumber
        ServerName      = $site.ServerName
        Type            = switch($site.Type) { 2 {"Primaire"} 1 {"Central"} 4 {"Secondaire"} default {$site.Type} }
        ParentSiteCode  = $site.ReportingSiteCode
        InstallDir      = $site.InstallDir
        SQLServer       = $site.SQLDatabaseName
    }
    Write-Log "Site MECM : $($site.SiteName) v$($site.Version)" "OK"
} catch {
    Write-Log "Erreur site MECM : $_" "ERROR"
}

# ─────────────────────────────────────────
# 2. RÔLES SYSTÈME DE SITE
# ─────────────────────────────────────────
Write-Log "Collecte des rôles système de site..."
try {
    $roles = Get-CMSiteSystemServer | Select-Object @(
        @{N="Serveur";E={ $_.NetworkOSPath -replace "\\\\","" }},
        @{N="Roles";E={ ($_ | Get-CMSiteRole | Select-Object -Expand RoleName) -join " | " }},
        "SiteCode",
        @{N="LastOnline";E={ $_.LastHeartbeat?.ToString("yyyy-MM-dd HH:mm") }}
    )
    $MECMData["RolesSite"] = $roles
    Write-Log "$($roles.Count) serveur(s) de site trouvé(s)" "OK"
} catch {
    Write-Log "Erreur rôles site : $_" "ERROR"
}

# ─────────────────────────────────────────
# 3. DISTRIBUTION POINTS
# ─────────────────────────────────────────
Write-Log "Collecte des Distribution Points..."
try {
    $DPs = Get-CMDistributionPoint | Select-Object @(
        @{N="Serveur";E={ $_.NetworkOSPath -replace "\\\\","" }},
        @{N="Site";E={ $_.SiteCode }},
        @{N="PXE";E={ $_.IsPXE }},
        @{N="Multicast";E={ $_.IsMulticast }},
        @{N="Groupe";E={
            (Get-CMDistributionPointGroup | Where-Object {
                $_.MemberCount -gt 0
            } | ForEach-Object {
                $grpName = $_.Name
                (Get-CMDistributionPointGroup -Name $grpName | Get-CMDistributionPoint |
                    Where-Object { $_.NetworkOSPath -eq $dp.NetworkOSPath }) |
                    ForEach-Object { $grpName }
            }) -join " | "
        }},
        @{N="BDP";E={ $_.AllowBranchDistributionPoint }}
    )
    $MECMData["DistributionPoints"] = $DPs
    Write-Log "$($DPs.Count) DP(s) trouvé(s)" "OK"
} catch {
    Write-Log "Erreur DPs : $_" "ERROR"
}

# ─────────────────────────────────────────
# 4. COLLECTIONS VDI
# ─────────────────────────────────────────
Write-Log "Collecte des collections VDI/Device..."
try {
    $Collections = Get-CMDeviceCollection | Where-Object {
        $_.Name -match "VDI|Horizon|Virtual|Desktop|Pool|Template|Thin|Workstation"
    } | Select-Object Name, CollectionID, Comment, MemberCount, LimitToCollectionName,
        @{N="RefreshType";E={ switch($_.RefreshType){ 1{"Manuel"} 2{"Périodique"} 4{"Incrémental"} 6{"Périodique+Incrémental"} default{$_.RefreshType} } }},
        @{N="LastRefresh";E={ $_.LastChangeTime?.ToString("yyyy-MM-dd HH:mm") }},
        @{N="QueryRule";E={
            ($_ | Get-CMDeviceCollectionQueryMembershipRule | Select-Object -Expand QueryExpression) -join " | "
        }}
    $MECMData["CollectionsVDI"] = $Collections
    Write-Log "$($Collections.Count) collection(s) VDI trouvée(s)" "OK"
} catch {
    Write-Log "Erreur collections : $_" "ERROR"
}

# ─────────────────────────────────────────
# 5. APPLICATIONS VDI
# ─────────────────────────────────────────
Write-Log "Collecte des applications MECM..."
try {
    $Apps = Get-CMApplication | Where-Object { $_.IsDeployed -eq $true } |
        Select-Object LocalizedDisplayName, SoftwareVersion, IsDeployed, NumberOfDeployments,
            @{N="Createur";E={ $_.CreatedBy }},
            @{N="Modifie";E={ $_.DateLastModified?.ToString("yyyy-MM-dd") }},
            @{N="Cible";E={ $_.NumberOfDevicesWithApp }},
            @{N="ContentSize";E={ [math]::Round($_.TotalContentSize/1MB, 2).ToString() + " GB" }}
    $MECMData["Applications"] = $Apps
    Write-Log "$($Apps.Count) application(s) trouvée(s)" "OK"
} catch {
    Write-Log "Erreur applications : $_" "ERROR"
}

# ─────────────────────────────────────────
# 6. SÉQUENCES DE TÂCHES VDI
# ─────────────────────────────────────────
Write-Log "Collecte des Task Sequences..."
try {
    $TSs = Get-CMTaskSequence | Select-Object Name, SequenceID,
        @{N="Modifie";E={ $_.LastModificationDate?.ToString("yyyy-MM-dd") }},
        @{N="BootImage";E={ $_.BootImageID }},
        @{N="Deploiements";E={ (Get-CMTaskSequenceDeployment -TaskSequenceId $_.PackageID).Count }},
        BootableMedia, PackageID
    $MECMData["TaskSequences"] = $TSs
    Write-Log "$($TSs.Count) Task Sequence(s) trouvée(s)" "OK"
} catch {
    Write-Log "Erreur Task Sequences : $_" "ERROR"
}

# ─────────────────────────────────────────
# 7. SOFTWARE UPDATE GROUPS (SUG)
# ─────────────────────────────────────────
Write-Log "Collecte des Software Update Groups..."
try {
    $SUGs = Get-CMSoftwareUpdateGroup | Select-Object LocalizedDisplayName, Updates,
        @{N="Cree";E={ $_.DateCreated?.ToString("yyyy-MM-dd") }},
        @{N="Modifie";E={ $_.DateLastModified?.ToString("yyyy-MM-dd") }},
        @{N="Expire";E={ $_.IsExpired }},
        @{N="NbUpdates";E={ $_.Updates.Count }}
    $MECMData["SoftwareUpdateGroups"] = $SUGs
    Write-Log "$($SUGs.Count) SUG(s) trouvé(s)" "OK"
} catch {
    Write-Log "Erreur SUGs : $_" "ERROR"
}

# ─────────────────────────────────────────
# 8. MAINTENANCE WINDOWS
# ─────────────────────────────────────────
Write-Log "Collecte des fenêtres de maintenance..."
try {
    $MWs = Get-CMDeviceCollection | ForEach-Object {
        $col = $_
        Get-CMMaintenanceWindow -CollectionId $col.CollectionID -ErrorAction SilentlyContinue |
            Select-Object @{N="Collection";E={ $col.Name }},
                Name, IsEnabled, DurationHours,
                @{N="Recurrence";E={ $_.ServiceWindowSchedules }},
                @{N="Type";E={ switch($_.ServiceWindowType){ 1{"General"} 4{"SoftwareUpdate"} 5{"OSD"} default{$_.ServiceWindowType} } }}
    }
    $MECMData["MaintenanceWindows"] = $MWs
    Write-Log "$($MWs.Count) maintenance window(s) trouvée(s)" "OK"
} catch {
    Write-Log "Erreur Maintenance Windows : $_" "ERROR"
}

# ─────────────────────────────────────────
# 9. PACKAGES / PILOTES
# ─────────────────────────────────────────
Write-Log "Collecte des packages de pilotes..."
try {
    $DriverPkgs = Get-CMDriverPackage | Select-Object Name, PackageID, Version,
        @{N="Modifie";E={ $_.LastRefreshTime?.ToString("yyyy-MM-dd") }},
        @{N="ContentSize";E={ [math]::Round($_.PackageSize/1KB,1).ToString() + " MB" }}
    $MECMData["PackagesPilotes"] = $DriverPkgs
    Write-Log "$($DriverPkgs.Count) package(s) pilote(s) trouvé(s)" "OK"
} catch {
    Write-Log "Erreur packages pilotes : $_" "ERROR"
}

Pop-Location

if ($ExportJson) {
    if (-not (Test-Path $OutputPath)) { New-Item -ItemType Directory -Path $OutputPath | Out-Null }
    $MECMData | ConvertTo-Json -Depth 10 | Out-File "$OutputPath\MECM_Info.json" -Encoding UTF8
    Write-Log "Export JSON : $OutputPath\MECM_Info.json" "OK"
}

Write-Log "=== COLLECTE MECM TERMINÉE ===" "OK"
return $MECMData
