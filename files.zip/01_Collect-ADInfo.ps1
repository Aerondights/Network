#Requires -Modules ActiveDirectory
<#
.SYNOPSIS
    Collecte toutes les informations Active Directory nécessaires à la gestion opérationnelle VDI.
.DESCRIPTION
    Récupère : Domaine, Contrôleurs de domaine, Sites & Subnets, OUs VDI, GPOs, Groupes, Comptes de service
.OUTPUTS
    Hashtable avec toutes les données AD
#>

[CmdletBinding()]
param(
    [string]$OutputPath = "$PSScriptRoot\..\output",
    [switch]$ExportJson
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Continue"

function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $color = switch ($Level) { "ERROR" { "Red" } "WARN" { "Yellow" } "OK" { "Green" } default { "Cyan" } }
    Write-Host "[$ts] [$Level] $Message" -ForegroundColor $color
}

Write-Log "=== COLLECTE ACTIVE DIRECTORY ===" "OK"

$ADData = [ordered]@{}

# ─────────────────────────────────────────
# 1. INFORMATIONS DOMAINE
# ─────────────────────────────────────────
Write-Log "Collecte des informations domaine..."
try {
    $domain = Get-ADDomain
    $forest = Get-ADForest
    $ADData["Domaine"] = [ordered]@{
        NomDNS              = $domain.DNSRoot
        NomNetBIOS          = $domain.NetBIOSName
        NiveauFonctionnel   = $domain.DomainMode.ToString()
        Forest              = $forest.Name
        NiveauForest        = $forest.ForestMode.ToString()
        SID                 = $domain.DomainSID.ToString()
        PDCEmulator         = $domain.PDCEmulator
        RIDMaster           = $domain.RIDMaster
        InfrastructureMaster = $domain.InfrastructureMaster
        SchemaMaster        = $forest.SchemaMaster
        NamingMaster        = $forest.DomainNamingMaster
        DistinguishedName   = $domain.DistinguishedName
    }
    Write-Log "Domaine : $($domain.DNSRoot)" "OK"
} catch {
    Write-Log "Erreur collecte domaine : $_" "ERROR"
    $ADData["Domaine"] = @{ Erreur = $_.Exception.Message }
}

# ─────────────────────────────────────────
# 2. CONTRÔLEURS DE DOMAINE
# ─────────────────────────────────────────
Write-Log "Collecte des contrôleurs de domaine..."
try {
    $DCs = Get-ADDomainController -Filter * | Select-Object @(
        "Name", "IPv4Address", "Site", "IsGlobalCatalog",
        "IsReadOnly", "OperatingSystem", "OperatingSystemVersion",
        @{N="FSMO";E={ ($_.OperationMasterRoles -join ", ") }},
        @{N="Enabled";E={ $_.Enabled }},
        @{N="Ping";E={ Test-Connection $_.IPv4Address -Count 1 -Quiet -ErrorAction SilentlyContinue }}
    )
    $ADData["ControleursDeDomaine"] = $DCs
    Write-Log "$($DCs.Count) DC(s) trouvé(s)" "OK"
} catch {
    Write-Log "Erreur collecte DCs : $_" "ERROR"
}

# ─────────────────────────────────────────
# 3. SITES AD & SUBNETS
# ─────────────────────────────────────────
Write-Log "Collecte des sites et subnets AD..."
try {
    $sites = Get-ADReplicationSite -Filter * | Select-Object Name, DistinguishedName,
        @{N="Subnets";E={
            (Get-ADReplicationSubnet -Filter "Site -eq '$($_.DistinguishedName)'" | Select-Object -Expand Name) -join " | "
        }}
    $ADData["SitesAD"] = $sites
    Write-Log "$($sites.Count) site(s) AD trouvé(s)" "OK"
} catch {
    Write-Log "Erreur collecte sites : $_" "ERROR"
}

# ─────────────────────────────────────────
# 4. GPOs
# ─────────────────────────────────────────
Write-Log "Collecte des GPOs..."
try {
    Import-Module GroupPolicy -ErrorAction Stop
    $GPOs = Get-GPO -All | Select-Object DisplayName, Id, GpoStatus,
        @{N="CreationDate";E={ $_.CreationTime.ToString("yyyy-MM-dd") }},
        @{N="ModifiedDate";E={ $_.ModificationTime.ToString("yyyy-MM-dd") }},
        @{N="WMIFilter";E={ $_.WmiFilter.Name }},
        @{N="LinkedOUs";E={
            $links = (Get-GPOReport -Guid $_.Id -ReportType XML -ErrorAction SilentlyContinue)
            if ($links) {
                $xml = [xml]$links
                ($xml.GPO.LinksTo | ForEach-Object { $_.SOMPath }) -join " | "
            } else { "N/A" }
        }}
    $ADData["GPOs"] = $GPOs
    Write-Log "$($GPOs.Count) GPO(s) trouvée(s)" "OK"
} catch {
    Write-Log "Erreur collecte GPOs : $_" "ERROR"
}

# ─────────────────────────────────────────
# 5. OUs VDI (filtrées sur les noms courants VDI)
# ─────────────────────────────────────────
Write-Log "Collecte des OUs liées VDI..."
try {
    $OUs = Get-ADOrganizationalUnit -Filter * -Properties Description, Created, Modified |
        Where-Object { $_.Name -match "VDI|Horizon|Virtual|Desktop|Pool|Template|Thin" } |
        Select-Object Name, DistinguishedName, Description,
            @{N="Created";E={ $_.Created.ToString("yyyy-MM-dd") }},
            @{N="Modified";E={ $_.Modified.ToString("yyyy-MM-dd") }},
            @{N="NbComputers";E={ (Get-ADComputer -Filter * -SearchBase $_.DistinguishedName -ErrorAction SilentlyContinue).Count }},
            @{N="NbUsers";E={ (Get-ADUser -Filter * -SearchBase $_.DistinguishedName -ErrorAction SilentlyContinue).Count }}
    $ADData["OUsVDI"] = $OUs
    Write-Log "$($OUs.Count) OU(s) VDI trouvée(s)" "OK"
} catch {
    Write-Log "Erreur collecte OUs : $_" "ERROR"
}

# ─────────────────────────────────────────
# 6. COMPTES DE SERVICE VDI
# ─────────────────────────────────────────
Write-Log "Collecte des comptes de service VDI..."
try {
    $ServiceAccounts = Get-ADUser -Filter {
        (SamAccountName -like "svc*" -or SamAccountName -like "srv*" -or
         Description -like "*VDI*" -or Description -like "*Horizon*" -or
         Description -like "*MECM*" -or Description -like "*SCCM*")
    } -Properties Description, PasswordLastSet, PasswordNeverExpires,
        AccountExpirationDate, LastLogonDate, Enabled |
        Select-Object SamAccountName, DisplayName, Description, Enabled,
            @{N="PasswordLastSet";E={ $_.PasswordLastSet?.ToString("yyyy-MM-dd") }},
            PasswordNeverExpires,
            @{N="LastLogon";E={ $_.LastLogonDate?.ToString("yyyy-MM-dd") }},
            @{N="Expiration";E={ $_.AccountExpirationDate?.ToString("yyyy-MM-dd") }},
            DistinguishedName
    $ADData["ComptesService"] = $ServiceAccounts
    Write-Log "$($ServiceAccounts.Count) compte(s) de service trouvé(s)" "OK"
} catch {
    Write-Log "Erreur collecte comptes service : $_" "ERROR"
}

# ─────────────────────────────────────────
# 7. GROUPES VDI
# ─────────────────────────────────────────
Write-Log "Collecte des groupes AD liés VDI..."
try {
    $Groups = Get-ADGroup -Filter {
        Name -like "*VDI*" -or Name -like "*Horizon*" -or Name -like "*Desktop*" -or Name -like "*Pool*"
    } -Properties Description, Members, ManagedBy |
        Select-Object Name, SamAccountName, GroupScope, GroupCategory, Description,
            @{N="NbMembres";E={ $_.Members.Count }},
            @{N="ManagedBy";E={ $_.ManagedBy }},
            DistinguishedName
    $ADData["GroupesVDI"] = $Groups
    Write-Log "$($Groups.Count) groupe(s) VDI trouvé(s)" "OK"
} catch {
    Write-Log "Erreur collecte groupes : $_" "ERROR"
}

# ─────────────────────────────────────────
# 8. STRATÉGIES DE MOT DE PASSE (PSO)
# ─────────────────────────────────────────
Write-Log "Collecte des stratégies de mots de passe (PSO)..."
try {
    $PSOs = Get-ADFineGrainedPasswordPolicy -Filter * |
        Select-Object Name, Precedence,
            @{N="MinLength";E={ $_.MinPasswordLength }},
            @{N="Complexity";E={ $_.ComplexityEnabled }},
            @{N="MaxAge";E={ $_.MaxPasswordAge.Days }},
            @{N="LockoutThreshold";E={ $_.LockoutThreshold }},
            @{N="LockoutDuration";E={ $_.LockoutDuration.Minutes }},
            @{N="AppliesTo";E={ ($_.AppliesTo | ForEach-Object { ($_ -split ",")[0] -replace "CN=" }) -join " | " }}
    $ADData["StratMDP"] = $PSOs
    Write-Log "$($PSOs.Count) PSO(s) trouvée(s)" "OK"
} catch {
    Write-Log "Erreur collecte PSO : $_" "ERROR"
}

# Export JSON optionnel
if ($ExportJson) {
    if (-not (Test-Path $OutputPath)) { New-Item -ItemType Directory -Path $OutputPath | Out-Null }
    $ADData | ConvertTo-Json -Depth 10 | Out-File "$OutputPath\AD_Info.json" -Encoding UTF8
    Write-Log "Export JSON : $OutputPath\AD_Info.json" "OK"
}

Write-Log "=== COLLECTE AD TERMINÉE ===" "OK"
return $ADData
