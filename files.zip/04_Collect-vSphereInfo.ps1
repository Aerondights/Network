#Requires -Modules VMware.PowerCLI
<#
.SYNOPSIS
    Collecte toutes les informations vSphere/vCenter nécessaires à la gestion VDI.
.DESCRIPTION
    Récupère : Clusters, Hosts ESXi, Datastores, Réseaux, Templates, Snapshots,
               Ressources, Tags, Alarmes actives
.NOTES
    Requiert : VMware PowerCLI - Install-Module VMware.PowerCLI
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string]$vCenterServer,

    [Parameter(Mandatory)]
    [System.Management.Automation.PSCredential]$vCenterCredential,

    [string]$OutputPath = "$PSScriptRoot\..\output",
    [switch]$ExportJson
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Continue"

function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $color = switch ($Level) { "ERROR" { "Red" } "WARN" { "Yellow" } "OK" { "Green" } default { "Cyan" } }
    Write-Host "[$ts] [$Level] $Message" -ForegroundColor $color
}

Write-Log "=== COLLECTE VSPHERE/VCENTER ===" "OK"

# Configuration PowerCLI
Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Confirm:$false | Out-Null
Set-PowerCLIConfiguration -DefaultVIServerMode Multiple -Confirm:$false | Out-Null

try {
    $vi = Connect-VIServer -Server $vCenterServer -Credential $vCenterCredential -ErrorAction Stop
    Write-Log "Connecté à $($vi.Name) v$($vi.Version) (Build $($vi.Build))" "OK"
} catch {
    Write-Log "Échec connexion vCenter : $_" "ERROR"
    return
}

$vSphereData = [ordered]@{}

# ─────────────────────────────────────────
# 1. VCENTER INFO
# ─────────────────────────────────────────
$vSphereData["vCenter"] = [ordered]@{
    Serveur         = $vi.Name
    Version         = $vi.Version
    Build           = $vi.Build
    Producteur      = $vi.ProductLine
    APIVersion      = $vi.ApiVersion
    ConnectedAs     = $vi.User
}

# ─────────────────────────────────────────
# 2. DATACENTERS & CLUSTERS
# ─────────────────────────────────────────
Write-Log "Collecte Datacenters & Clusters..."
try {
    $Clusters = Get-Cluster | Select-Object @(
        "Name",
        @{N="Datacenter";E={ (Get-Datacenter -VMHost (Get-VMHost -Location $_)[0]).Name }},
        @{N="NbHosts";E={ ($_ | Get-VMHost).Count }},
        @{N="NbVMs";E={ ($_ | Get-VM).Count }},
        @{N="DRS";E={ $_.DrsEnabled }},
        @{N="DRSMode";E={ $_.DrsAutomationLevel }},
        @{N="HA";E={ $_.HAEnabled }},
        @{N="HAAdmissionControl";E={ $_.HAAdmissionControlEnabled }},
        @{N="vSAN";E={ $_.VsanEnabled }},
        @{N="EVC";E={ $_.EVCMode }},
        @{N="CPUTotal_GHz";E={ [math]::Round(($_ | Get-VMHost | Measure-Object -Property CpuTotalMhz -Sum).Sum / 1000, 1) }},
        @{N="RAMTotal_GB";E={ [math]::Round(($_ | Get-VMHost | Measure-Object -Property MemoryTotalGB -Sum).Sum, 0) }},
        @{N="CPUUsage_Pct";E={
            $total = ($_ | Get-VMHost | Measure-Object -Property CpuTotalMhz -Sum).Sum
            $used  = ($_ | Get-VMHost | Measure-Object -Property CpuUsageMhz -Sum).Sum
            if ($total -gt 0) { [math]::Round($used/$total*100, 1) } else { 0 }
        }},
        @{N="RAMUsage_Pct";E={
            $totalGB = ($_ | Get-VMHost | Measure-Object -Property MemoryTotalGB -Sum).Sum
            $usedGB  = ($_ | Get-VMHost | Measure-Object -Property MemoryUsageGB -Sum).Sum
            if ($totalGB -gt 0) { [math]::Round($usedGB/$totalGB*100, 1) } else { 0 }
        }}
    )
    $vSphereData["Clusters"] = $Clusters
    Write-Log "$($Clusters.Count) cluster(s) trouvé(s)" "OK"
} catch { Write-Log "Erreur Clusters : $_" "ERROR" }

# ─────────────────────────────────────────
# 3. HOSTS ESXi
# ─────────────────────────────────────────
Write-Log "Collecte des hosts ESXi..."
try {
    $Hosts = Get-VMHost | Select-Object @(
        "Name",
        @{N="Cluster";E={ (Get-Cluster -VMHost $_).Name }},
        @{N="Version";E={ $_.Version }},
        @{N="Build";E={ $_.Build }},
        @{N="Etat";E={ $_.ConnectionState }},
        @{N="Mode";E={ $_.PowerState }},
        @{N="Maintenance";E={ $_.State -eq "Maintenance" }},
        @{N="CPU_Sockets";E={ ($_ | Get-VMHostHardware).CpuCount }},
        @{N="CPU_Cores";E={ $_.NumCpu }},
        @{N="CPU_Mhz";E={ $_.CpuTotalMhz }},
        @{N="RAM_GB";E={ [math]::Round($_.MemoryTotalGB, 0) }},
        @{N="RAMUsed_GB";E={ [math]::Round($_.MemoryUsageGB, 1) }},
        @{N="NbVMs";E={ ($_ | Get-VM).Count }},
        @{N="Uptime_Jours";E={ [math]::Round((Get-Stat -Entity $_ -Stat "sys.uptime.latest" -Realtime -MaxSamples 1 -ErrorAction SilentlyContinue).Value / 86400, 1) }},
        @{N="HyperThreading";E={ $_.HyperthreadingActive }},
        @{N="IP_Management";E={ ($_ | Get-VMHostNetworkAdapter -VMKernel | Where-Object { $_.ManagementTrafficEnabled }).IP }},
        @{N="IP_vMotion";E={ ($_ | Get-VMHostNetworkAdapter -VMKernel | Where-Object { $_.VMotionEnabled }).IP }},
        @{N="IP_vSAN";E={ ($_ | Get-VMHostNetworkAdapter -VMKernel | Where-Object { $_.VSANTrafficEnabled }).IP }}
    )
    $vSphereData["HostsESXi"] = $Hosts
    Write-Log "$($Hosts.Count) host(s) ESXi trouvé(s)" "OK"
} catch { Write-Log "Erreur Hosts : $_" "ERROR" }

# ─────────────────────────────────────────
# 4. DATASTORES
# ─────────────────────────────────────────
Write-Log "Collecte des Datastores..."
try {
    $Datastores = Get-Datastore | Select-Object @(
        "Name",
        @{N="Type";E={ $_.Type }},
        @{N="CapacityGB";E={ [math]::Round($_.CapacityGB, 1) }},
        @{N="FreeGB";E={ [math]::Round($_.FreeSpaceGB, 1) }},
        @{N="UsedPct";E={ [math]::Round(($_.CapacityGB - $_.FreeSpaceGB) / $_.CapacityGB * 100, 1) }},
        @{N="NbVMs";E={ ($_ | Get-VM).Count }},
        @{N="Accessible";E={ $_.State }},
        @{N="Hosts";E={ ($_ | Get-VMHost | Select-Object -Expand Name) -join " | " }}
    )
    $vSphereData["Datastores"] = $Datastores
    Write-Log "$($Datastores.Count) datastore(s) trouvé(s)" "OK"
} catch { Write-Log "Erreur Datastores : $_" "ERROR" }

# ─────────────────────────────────────────
# 5. RÉSEAUX (Port Groups)
# ─────────────────────────────────────────
Write-Log "Collecte des réseaux (Port Groups)..."
try {
    $PGs = Get-VDPortgroup | Select-Object @(
        "Name",
        @{N="vSwitch";E={ $_.VDSwitch.Name }},
        @{N="VLAN";E={ $_.VlanConfiguration }},
        @{N="NbPorts";E={ $_.NumPorts }},
        @{N="NbVMs";E={ ($_ | Get-VM).Count }},
        "Key"
    )
    $vSphereData["ReseauxVDS"] = $PGs

    # Standard vSwitches aussi
    $StdPGs = Get-VirtualPortGroup | Select-Object @(
        "Name",
        @{N="vSwitch";E={ $_.VirtualSwitchName }},
        @{N="VLAN";E={ $_.VLanId }},
        "Key"
    )
    $vSphereData["ReseauxStd"] = $StdPGs
    Write-Log "$($PGs.Count + $StdPGs.Count) port group(s) trouvé(s)" "OK"
} catch { Write-Log "Erreur réseaux : $_" "ERROR" }

# ─────────────────────────────────────────
# 6. TEMPLATES VDI (Golden Images)
# ─────────────────────────────────────────
Write-Log "Collecte des Templates/Golden Images..."
try {
    $Templates = Get-Template | Select-Object @(
        "Name",
        @{N="OS";E={ $_.ExtensionData.Config.GuestFullName }},
        @{N="CPU";E={ $_.NumCpu }},
        @{N="RAM_GB";E={ [math]::Round($_.MemoryGB, 0) }},
        @{N="Disques_GB";E={ ($_ | Get-HardDisk | Measure-Object -Property CapacityGB -Sum).Sum }},
        @{N="Datastore";E={ ($_ | Get-HardDisk | Select-Object -First 1).Filename.Split("]")[0].TrimStart("[") }},
        @{N="Cluster";E={ (Get-Cluster -VM (Set-Template $_ -ToVM -Confirm:$false -WhatIf 2>$null)).Name }}
    )

    # Snapshots sur les VMs qui servent de référence Instant Clone
    $ICSnapshots = Get-VM | Where-Object { $_.Name -match "golden|template|base|parent|master|ic-" } |
        Select-Object @(
            "Name",
            @{N="Snapshot";E={ (Get-Snapshot -VM $_).Name }},
            @{N="SnapshotDate";E={ (Get-Snapshot -VM $_).Created?.ToString("yyyy-MM-dd HH:mm") }},
            @{N="RAM_GB";E={ [math]::Round($_.MemoryGB, 0) }},
            @{N="CPU";E={ $_.NumCpu }},
            @{N="OS";E={ $_.ExtensionData.Config.GuestFullName }}
        )

    $vSphereData["Templates"] = $Templates
    $vSphereData["GoldenImages"] = $ICSnapshots
    Write-Log "$($Templates.Count) template(s) & $($ICSnapshots.Count) golden image(s) trouvé(s)" "OK"
} catch { Write-Log "Erreur Templates : $_" "ERROR" }

# ─────────────────────────────────────────
# 7. ALARMES ACTIVES
# ─────────────────────────────────────────
Write-Log "Collecte des alarmes actives..."
try {
    $Alarms = Get-AlarmDefinition | ForEach-Object {
        $alarm = $_
        Get-Folder -Type Datacenter | ForEach-Object {
            $_.ExtensionData.TriggeredAlarmState | Where-Object {
                $_.Alarm.ToString() -eq $alarm.Id
            } | ForEach-Object {
                [ordered]@{
                    Alarme      = $alarm.Name
                    Entite      = $_.Entity.ToString()
                    Statut      = $_.OverallStatus
                    Declenchee  = $_.Time.ToString("yyyy-MM-dd HH:mm")
                    Acquittee   = $_.Acknowledged
                }
            }
        }
    }
    $vSphereData["AlarmsActives"] = $Alarms
    Write-Log "$($Alarms.Count) alarme(s) active(s)" "OK"
} catch { Write-Log "Erreur alarmes : $_" "ERROR" }

# ─────────────────────────────────────────
# 8. LICENCES vSphere
# ─────────────────────────────────────────
Write-Log "Collecte des licences vSphere..."
try {
    $LicMgr = Get-View LicenseManager
    $Licences = $LicMgr.Licenses | Select-Object @(
        @{N="Produit";E={ $_.Name }},
        @{N="Cle";E={ $_.LicenseKey }},
        @{N="Total";E={ $_.Total }},
        @{N="Utilise";E={ $_.Used }},
        @{N="Restant";E={ $_.Total - $_.Used }},
        @{N="Expiration";E={ ($_.Properties | Where-Object { $_.Key -eq "expirationDate" }).Value }},
        @{N="Type";E={ $_.Edition }}
    )
    $vSphereData["Licences"] = $Licences
    Write-Log "$($Licences.Count) licence(s) trouvée(s)" "OK"
} catch { Write-Log "Erreur licences : $_" "ERROR" }

Disconnect-VIServer -Server $vCenterServer -Confirm:$false
Write-Log "Déconnexion vCenter OK" "OK"

if ($ExportJson) {
    if (-not (Test-Path $OutputPath)) { New-Item -ItemType Directory -Path $OutputPath | Out-Null }
    $vSphereData | ConvertTo-Json -Depth 10 | Out-File "$OutputPath\vSphere_Info.json" -Encoding UTF8
    Write-Log "Export JSON : $OutputPath\vSphere_Info.json" "OK"
}

Write-Log "=== COLLECTE VSPHERE TERMINÉE ===" "OK"
return $vSphereData
